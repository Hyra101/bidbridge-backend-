const { body } = require("express-validator");

const validateAddJobApplicationData = [
  body("applicantName").notEmpty().withMessage("Applicant name is required"),
  body("applicantEmail")
    .notEmpty()
    .withMessage("Applicant email is required")
    .isEmail()
    .withMessage("Applicant email is invalid"),
  body("applicantCV").notEmpty().withMessage("Applicant CV is required"),
];

module.exports = { validateAddJobApplicationData };
