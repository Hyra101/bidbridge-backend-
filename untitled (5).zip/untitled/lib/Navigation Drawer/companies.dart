import 'package:flutter/material.dart';

import '../companies/Company.dart';
import '../companies/CompanyDetailScreen.dart';
import '../companies/CompanyListScreen.dart';

class Companies extends StatefulWidget {
  const Companies({super.key});

  @override
  State<Companies> createState() => _CompaniesState();
}

class _CompaniesState extends State<Companies> {
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
       appBar: AppBar(
        centerTitle: true,
        title: Text(
          'Companies',
          style: TextStyle(fontWeight: FontWeight.w600, fontSize: 19),
        ),
        elevation: 1,
      ),

      body: Column(
        children: [

          SizedBox(
            height: 13,
          ),
             Column(
                    // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: Company.companies.take(3).map((company) {
                      return GestureDetector(
                        child: CompanyCard(company: company),
                        onTap: () {
                          Navigator.push(context,
                              MaterialPageRoute(builder: (_) {
                            return CompanyDetailScreen(company: company);
                          }));
                        },
                      );
                    }).toList(),
                  ),
        ],
      ),
    );
  }
}