import 'package:flutter/material.dart';

class ManageJobsScreen extends StatefulWidget {
  const ManageJobsScreen({super.key});

  @override
  State<ManageJobsScreen> createState() => _ManageJobsScreenState();
}

class _ManageJobsScreenState extends State<ManageJobsScreen> {
  List<String> status = [
    'Pending',
    'Expiring',
    'Pending',
  ];

  List<String> titles = [
    'Frontend React Developer',
    'Full Stack PHP Developer',
    'Node.js Developer',
  ];
  List<String> expires = [
    'Expiring on 10 August, 2019',
    'Expiring on 28 July, 2019',
    'Expiring on 3 october, 2019',
  ];
  List<String> time = [
    'Posted on 10 July, 2019',
    'Posted on 28 June, 2019',
    'Posted on 16 May, 2019',
  ];
  List<String> fixedPrice = [
    '\$2,500 - \$4,500',
    '\$500 - \$1,200',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Manage Tasks'),
        elevation: 1,
        centerTitle: true,
      ),
      body: ListView.builder(
        itemCount: 3,
        physics: BouncingScrollPhysics(),
        shrinkWrap: true,
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Card(
              color: Colors.white,
              elevation: 2,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(6)),
              child: Container(
                margin: EdgeInsets.symmetric(vertical: 7),
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                width: double.infinity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          titles[index],
                          style:
                              TextStyle(fontWeight: FontWeight.w500, fontSize: 15),
                        ),

                        Container(
                          // width: MediaQuery.of(context).size.width * .32,
                          padding:
                              EdgeInsets.symmetric(vertical: 4, horizontal: 6),
                          decoration: BoxDecoration(
                              color: Colors.green.shade400,
                              borderRadius: BorderRadius.circular(4)),
                          child: Text(
                            status[index],
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 4,
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.date_range,
                          size: 16,
                          color: Color(0x99131A22),
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        Text(time[index])
                      ],
                    ),
                    SizedBox(
                      height: 6,
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.date_range,
                          size: 16,
                          color: Color(0x99131A22),
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        Text(expires[index])
                      ],
                    ),
                    SizedBox(
                      height: 19,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          // width: MediaQuery.of(context).size.width * .32,
                          padding:
                              EdgeInsets.symmetric(vertical: 6, horizontal: 5),
                          decoration: BoxDecoration(
                              color: Color(0xff770737),
                              borderRadius: BorderRadius.circular(4)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.people,
                                color: Colors.white,
                                size: 19,
                              ),
                              SizedBox(
                                width: 4,
                              ),
                              Text(
                                'Manage Candidates',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13),
                              ),
                            ],
                          ),
                        ),
                        Row(
                          children: [
                            Container(
                                padding: EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                    color: Colors.grey.shade200,
                                    borderRadius: BorderRadius.circular(3)),
                                child: Icon(
                                  Icons.edit,
                                  color: Color(0x99131A22),
                                )),
                            SizedBox(
                              width: 15,
                            ),
                            Container(
                                padding: EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                    color: Colors.grey.shade200,
                                    borderRadius: BorderRadius.circular(3)),
                                child: Icon(
                                  Icons.delete,
                                  color: Color(0x99131A22),
                                )),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
