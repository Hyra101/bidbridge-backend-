import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

class ManageBiddersScreen extends StatefulWidget {
  const ManageBiddersScreen({super.key});

  @override
  State<ManageBiddersScreen> createState() => _ManageBiddersScreenState();
}

class _ManageBiddersScreenState extends State<ManageBiddersScreen> {
  List<String> names = [
    'Sandy Forest',
    'Nicholy arzov',
    'Tom Smith',
  ];
  List<String> prices = [
    '3000',
    '2400',
    '1600',
  ];
    List<String> days = [
    '16',
    '12',
    '28',
  ];
  List<String> emails = [
    'sandy33@gmail.com',
    'nicholy73@gmail.com',
    'tom152@gmail.com',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Manage Candidates'),
        elevation: 1,
        centerTitle: true,
      ),
      body: ListView.builder(
        itemCount: imgList.length,
        physics: BouncingScrollPhysics(),
        shrinkWrap: true,
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Card(
              color: Colors.white,
              elevation: 4,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(6)),
              child: Container(
                margin: EdgeInsets.symmetric(vertical: 7),
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                width: double.infinity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 36,
                          backgroundImage: NetworkImage(imgList[index]),
                        ),
                        SizedBox(
                          width: 9,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              names[index],
                              style: TextStyle(fontWeight: FontWeight.w500),
                            ),
                            Row(
                              children: [
                                Icon(
                                  Icons.email,
                                  size: 21,
                                  color: Color(0x99131A22),
                                ),
                                SizedBox(
                                  width: 6,
                                ),
                                Text(
                                  emails[index],
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: Color(0x99131A22),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        )
                      ],
                    ),
                    SizedBox(
                      height: 6,
                    ),
                    RatingBar.builder(
                        initialRating: index + 2,
                        minRating: 0,
                        direction: Axis.horizontal,
                        allowHalfRating: true,
                        itemCount: 5,
                        itemSize: 20,
                        itemPadding:
                            const EdgeInsets.symmetric(horizontal: 2.0),
                        itemBuilder: (context, _) => const Icon(
                              Icons.star,
                              color: Colors.amber,
                              size: 26,
                            ),
                        onRatingUpdate: (rating) async {}),
                  
      
                    Container(
                      width: double.infinity,
                      padding: EdgeInsets.symmetric(horizontal: 16,vertical: 9),
                      margin: EdgeInsets.symmetric(vertical: 19),
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(4),color: Colors.grey.shade300),child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Fixed Price'),
                              Text('\$${prices[index]}',style: TextStyle(fontWeight: FontWeight.w500),),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Delivery time'),
                              Text('${days[index]} days',style: TextStyle(fontWeight: FontWeight.w500),),
                            ],
                          )
                        ],
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width * .32,
                          padding: EdgeInsets.symmetric(vertical: 6),
                          decoration: BoxDecoration(
                              color: Color(0xff770737),
                              borderRadius: BorderRadius.circular(4)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.done,
                                color: Colors.white,
                                size: 19,
                              ),
                              SizedBox(
                                width: 4,
                              ),
                              Text(
                                'Accept offers',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width * .34,
                          padding: EdgeInsets.symmetric(vertical: 6),
                          decoration: BoxDecoration(
                              color: Colors.black,
                              borderRadius: BorderRadius.circular(4)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.chat,
                                color: Colors.white,
                                size: 19,
                              ),
                              SizedBox(
                                width: 4,
                              ),
                              Text(
                                'Send Message',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13),
                              ),
                            ],
                          ),
                        ),
                        Icon(Icons.delete,color:Color(0xff770737))
                      ],
                    ),
      
      
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  final List<String> imgList = [
    'https://images.unsplash.com/photo-1522205408450-add114ad53fe?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=368f45b0888aeb0b7b08e3a1084d3ede&auto=format&fit=crop&w=1950&q=80',
    'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=94a1e718d89ca60a6337a6008341ca50&auto=format&fit=crop&w=1950&q=80',
    'https://images.unsplash.com/photo-1523205771623-e0faa4d2813d?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=89719a0d55dd05e2deae4120227e6efc&auto=format&fit=crop&w=1953&q=80',
  ];
}
