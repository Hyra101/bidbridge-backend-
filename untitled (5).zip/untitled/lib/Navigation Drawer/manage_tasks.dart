import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

class ManageTasksScreen extends StatefulWidget {
  const ManageTasksScreen({super.key});

  @override
  State<ManageTasksScreen> createState() => _ManageTasksScreenState();
}

class _ManageTasksScreenState extends State<ManageTasksScreen> {
  List<String> names = [
    'Sandy Forest',
    'Nicholy arzov',
    'Tom Smith',
  ];

  List<String> titles = [
    'Design a Landing Page ',
    'Food Delivery Mobile Application',
  ];
  List<String> prices = [
    '3000',
    '34',
  ];
  List<String> time = [
    '6 days, 23 hours left',
    '32 hours',
  ];
  List<String> fixedPrice = [
    '\$2,500 - \$4,500',
    '\$500 - \$1,200',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Manage Tasks'),
        elevation: 1,
        centerTitle: true,
      ),
      body: ListView.builder(
        itemCount: 2,
        physics: BouncingScrollPhysics(),
        shrinkWrap: true,
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Card(
              color: Colors.white,
              elevation: 2,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(6)),
              child: Container(
                margin: EdgeInsets.symmetric(vertical: 7),
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                width: double.infinity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                                  titles[index],
                                  style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),
                                ),

                                SizedBox(
                                  height: 4,
                                ),
                                Row(
                                  children: [
                                    Icon(Icons.access_time,
                                    size: 16,
                              color: Color(0x99131A22),

                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(time[index])
                                  ],
                                ),
                   
                    Container(
                      width: double.infinity,
                      padding:
                          EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                      margin: EdgeInsets.symmetric(vertical: 19),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          color: Colors.grey.shade200),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Bids'),
                              Text(
                                '3',
                                style: TextStyle(fontWeight: FontWeight.w500,fontSize: 12),
                              ),
                            ],
                          ),
                         Container(
                          height: 34,
                          width: 1,
                          color: Colors.black54,
                         ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Avg.Bid'),
                              Text(
                                '\$${prices[index]}',
                                style: TextStyle(fontWeight: FontWeight.w500,
                                fontSize: 12),
                              ),
                            ],
                          ),
                           Container(
                          height: 34,
                          width: 1,
                          color: Colors.black54,
                         )
                          , Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Fixed Price'),
                              Text(
                                '\$${fixedPrice[index]}',
                                style: TextStyle(fontWeight: FontWeight.w500,
                                fontSize: 12),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          // width: MediaQuery.of(context).size.width * .32,
                          padding: EdgeInsets.symmetric(vertical: 6,horizontal: 5),
                          decoration: BoxDecoration(
                              color: Color(0xff770737),
                              borderRadius: BorderRadius.circular(4)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.people,
                                color: Colors.white,
                                size: 19,
                              ),
                              SizedBox(
                                width: 4,
                              ),
                              Text(
                                'Manage Bidders',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13),
                              ),
                            ],
                          ),
                        ),
                        Row(
                          children: [
                            Container(
                                padding: EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                    color: Colors.grey.shade200,
                                    borderRadius: BorderRadius.circular(3)),
                                child: Icon(
                                  Icons.edit,
                                  color: Color(0x99131A22),
                                )),

                                SizedBox(
                                  width: 15,
                                ),
                                 Container(
                            padding: EdgeInsets.all(5),
                            decoration: BoxDecoration(
                                color: Colors.grey.shade200,
                                borderRadius: BorderRadius.circular(3)),
                            child: Icon(
                              Icons.delete,
                              color: Color(0x99131A22),
                            )),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

}
