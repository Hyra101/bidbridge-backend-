import 'package:flutter/material.dart';

class MyActiveBids extends StatefulWidget {
  const MyActiveBids({super.key});

  @override
  State<MyActiveBids> createState() => _MyActiveBidsState();
}

class _MyActiveBidsState extends State<MyActiveBids> {
  List<String> names = [
    'Sandy Forest',
    'Nicholy arzov',
    'Tom Smith',
  ];

  List<String> titles = [
    'WordPress Guru Neede',
    'Build me a website in Angular JS',
    'Android and iOS React Appe',
    'Write Simple Python Script',
  ];
  List<String> prices = [
    '100',
    '2500',
    '3000',
    '34',
  ];
  List<String> time = [
    '14',
    '2',
    '21',
    '1',
  ];
  List<String> fixedPrice = [
    '\$2,500 - \$4,500',
    '\$500 - \$1,200',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Active Bids'),
        elevation: 1,
        centerTitle: true,
      ),
      body: ListView.builder(
        itemCount: 4,
        physics: BouncingScrollPhysics(),
        shrinkWrap: true,
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Card(
              color: Colors.white,
              elevation: 2,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(6)),
              child: Container(
                margin: EdgeInsets.symmetric(vertical: 7),
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                width: double.infinity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                                  titles[index],
                                  style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),
                                ),

                               
                                
                   
                    Container(
                      width: double.infinity,
                      padding:
                          EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                      margin: EdgeInsets.symmetric(vertical: 19),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          color: Colors.grey.shade200),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Fixed Price'),
                              Text(
                                '\$${prices[index]}',
                                style: TextStyle(fontWeight: FontWeight.w500,
                                fontSize: 12),
                              ),
                            ],
                          ),
                             Container(
                          height: 34,
                          width: 1,
                          color: Colors.black54,
                         )
                          , 
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Delivery Time'),
                              Text(
                                '${time[index]} days',
                                style: TextStyle(fontWeight: FontWeight.w500,
                                fontSize: 12),
                              ),
                            ],
                          ),
                        
                        ],
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                       
                        Row(
                          children: [
                            Container(
                                padding: EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                    color: Color(0xff770737),
                                    borderRadius: BorderRadius.circular(3)),
                                child: Icon(
                                  Icons.edit,
                                  // color: Color(0x99131A22),
                                  color: Colors.white,
                                )),

                                SizedBox(
                                  width: 15,
                                ),
                                 Container(
                            padding: EdgeInsets.all(5),
                            decoration: BoxDecoration(
                                color: Colors.red,
                                borderRadius: BorderRadius.circular(3)),
                            child: Icon(
                              Icons.delete,
                                  color: Colors.white,

                              // color: Color(0x99131A22),
                            )),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

}
