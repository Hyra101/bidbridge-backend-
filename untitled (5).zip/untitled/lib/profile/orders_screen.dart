import 'package:flutter/material.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
 @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Orders'),
        elevation: 1,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            children: [
        
              SizedBox(
                height: 12,
              ),
              Card(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(6)),
                child: Container(
                  width: double.infinity,
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                          'Professional plan',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w500,
                          ),),
                      SizedBox(
                        height: 7,
                      ),
                    Text('Order: #228'),
                    Text('Date: 12/7/2022'),
                    SizedBox(
                      height: 10,
                    ),
                      Container(
                            width: MediaQuery.of(context).size.width * .2,
                            padding: EdgeInsets.symmetric(vertical: 6),
                            decoration: BoxDecoration(
                                color: Colors.redAccent,
                                borderRadius: BorderRadius.circular(4)),
                            child: Center(
                                child: Text(
                              'Unpaid',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 13),
                            )),
                          ),
                    ],
                  ),
                ),
              ),SizedBox(
                height: 9,
              ),
              Card(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(6)),
                child: Container(
                  width: double.infinity,
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                          'Professional plan',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w500,
                          ),),
                      SizedBox(
                        height: 7,
                      ),
                    Text('Order: #264'),
                    Text('Date: 22/7/2020'),
                    SizedBox(
                      height: 10,
                    ),
                      Container(
                            width: MediaQuery.of(context).size.width * .2,
                            padding: EdgeInsets.symmetric(vertical: 6),
                            decoration: BoxDecoration(
                                color: Colors.green,
                                borderRadius: BorderRadius.circular(4)),
                            child: Center(
                                child: Text(
                              'Paid',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 13),
                            )),
                          ),
                    ],
                  ),
                ),
              ),SizedBox(
                height: 9,
              ),Card(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(6)),
                child: Container(
                  width: double.infinity,
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                          'Professional plan',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w500,
                          ),),
                      SizedBox(
                        height: 7,
                      ),
                    Text('Order: #326'),
                    Text('Date: 12/4/2019'),
                    SizedBox(
                      height: 10,
                    ),
                      Container(
                            width: MediaQuery.of(context).size.width * .2,
                            padding: EdgeInsets.symmetric(vertical: 6),
                            decoration: BoxDecoration(
                                color: Colors.green,
                                borderRadius: BorderRadius.circular(4)),
                            child: Center(
                                child: Text(
                              'Paid',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 13),
                            )),
                          ),
                    ],
                  ),
                ),
              ),SizedBox(
                height: 9,
              ),Card(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(6)),
                child: Container(
                  width: double.infinity,
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                          'Professional plan',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w500,
                          ),),
                      SizedBox(
                        height: 7,
                      ),
                    Text('Order: #166'),
                    Text('Date: 07/9/2022'),
                    SizedBox(
                      height: 10,
                    ),
                      Container(
                            width: MediaQuery.of(context).size.width * .2,
                            padding: EdgeInsets.symmetric(vertical: 6),
                            decoration: BoxDecoration(
                                color: Colors.green,
                                borderRadius: BorderRadius.circular(4)),
                            child: Center(
                                child: Text(
                              'Paid',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 13),
                            )),
                          ),
                    ],
                  ),
                ),
              ),SizedBox(
                height: 9,
              ),
             
            ],
          ),
        ),
      ),
    );
  }
}
