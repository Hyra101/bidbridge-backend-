import 'package:flutter/material.dart';
import 'package:untitled/chats/ChatListScreen.dart';
import 'package:untitled/profile/notes_screen.dart';
import 'package:untitled/profile/orders_screen.dart';

import '../notifications/Notification Screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff770737),
        actions: [
          IconButton(
              onPressed: () {
                    Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => NotificationsScreen()));
              },
              icon: Icon(
                Icons.notifications,
                color: Colors.white,
              ))
        ],
      ),
      body: Column(
        children: [
          Container(
            height: MediaQuery.of(context).size.height * .12,
            padding: EdgeInsets.only(left: 19, bottom: 18),
            decoration: BoxDecoration(
              color: Color(0xff770737),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 38,
                  child: Icon(
                    Icons.person,
                    size: 44,
                  ),
                ),
                SizedBox(
                  width: 16,
                ),
                Text(
                  'Jam Faraz',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w600),
                )
              ],
            ),
          ),
          SizedBox(
            height: 14,
          ),

          Container(
            margin: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            padding: EdgeInsets.symmetric(horizontal: 22, vertical: 8),
            decoration: BoxDecoration(
                color: Colors.grey.shade200,
                borderRadius: BorderRadius.circular(8)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Task Bids',
                      style: TextStyle(),
                    ),
                    Text(
                      '14',
                      style: TextStyle(
                          color: Colors.green, fontWeight: FontWeight.bold),
                    )
                  ],
                ),
                ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: Image.asset(
                      'assets/task.jpg',
                      height: 68,
                    )),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            padding: EdgeInsets.symmetric(horizontal: 22, vertical: 8),
            decoration: BoxDecoration(
                color: Colors.grey.shade200,
                borderRadius: BorderRadius.circular(8)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Jobs Applied',
                      style: TextStyle(),
                    ),
                    Text(
                      '7',
                      style: TextStyle(
                          color: Colors.green, fontWeight: FontWeight.bold),
                    )
                  ],
                ),
                ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: Image.asset(
                      'assets/job.jpg',
                      height: 68,
                    )),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            padding: EdgeInsets.symmetric(horizontal: 22, vertical: 8),
            decoration: BoxDecoration(
                color: Colors.grey.shade200,
                borderRadius: BorderRadius.circular(8)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Reviews',
                      style: TextStyle(),
                    ),
                    Text(
                      '34',
                      style: TextStyle(
                          color: Colors.green, fontWeight: FontWeight.bold),
                    )
                  ],
                ),
                ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: Image.asset(
                      'assets/review.jpg',
                      height: 68,
                    )),
              ],
            ),
          ),

          SizedBox(
            height: 32,
          ),
          ProfileWidget(
            text: 'Notes',
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => NotesScreen()));
            },
          ),
          ProfileWidget(
            text: 'Messages',
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => ChatListScreen()));
            },
          ),
          ProfileWidget(
            text: 'Orders',
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => OrdersScreen()));
            },
          ),

          //  ProfileWidget(
          //   text: 'Notes',
          //   onTap: () {},
          // ), ProfileWidget(
          //   text: 'Messages',
          //   onTap: () {},
          // )
        ],
      ),
    );
  }
}

class ProfileWidget extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const ProfileWidget({
    super.key,
    required this.text,
    required this.onTap,
  });
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        // height: 47,
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 16),
        decoration: ShapeDecoration(
          color: Colors.white,
          shape: RoundedRectangleBorder(
            side: const BorderSide(
              width: 1,
              strokeAlign: BorderSide.strokeAlignOutside,
              color: Color(0xFFF1F1F1),
            ),
            borderRadius: BorderRadius.circular(10),
          ),
          // shadows: const [
          //   BoxShadow(
          //     color: Color(0x3F000000),
          //     blurRadius: 4,
          //     offset: Offset(-1, 1),
          //     spreadRadius: 0,
          //   )
          // ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              text,
              style: const TextStyle(
                color: Color(0x99131A22),
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
            const Icon(
              Icons.arrow_forward_ios,
              size: 21,
              color: Color(0x99131A22),
            )
          ],
        ),
      ),
    );
  }
}
