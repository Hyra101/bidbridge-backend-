import 'package:flutter/material.dart';

class TabBarItem extends StatelessWidget {
  final String title;
  final bool isSelected;
  final Color selectedColor;

  const TabBarItem({
    super.key,
    required this.title,
    required this.isSelected,
    required this.selectedColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(
          color: isSelected ?  Colors.green : selectedColor,
          borderRadius: BorderRadius.circular(4),
        ),
        child: Center(
          child: Text(
            title,
            style:  TextStyle(
             color:isSelected?Colors.white: Color(0xFF1F0101),
          // fontSize: 14,
          fontWeight: FontWeight.w600
            ),
          ),
        ));
  }
}
