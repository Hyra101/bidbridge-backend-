import 'package:flutter/material.dart';
import 'package:untitled/googlsignin/GoogleSignIn.dart';
import 'package:untitled/login_screen/RegisterNewUser.dart';

import 'package:untitled/login_screen/login_screen.dart';

import '../widgets/primary_textfield.dart';
import '../widgets/tabbar_item.dart';
import 'LoginApiHandler.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({Key? key}) : super(key: key);

  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage>



 with SingleTickerProviderStateMixin {
  late TabController tabController;

  @override
  void initState() {
    tabController = TabController(length: 2, vsync: this);
    super.initState();
    tabController.addListener(() {
      setState(() {});
    });
  }
  TextEditingController gmailController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController retypeController = TextEditingController();

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: null,
//       body: SingleChildScrollView( // Wrap the Stack with SingleChildScrollView
//         child: Stack(
//           children: <Widget>[
//             Column(
//               crossAxisAlignment: CrossAxisAlignment.stretch,
//               mainAxisAlignment: MainAxisAlignment.start,
//               children: <Widget>[
//                 Container(
//                   width: MediaQuery.of(context).size.width,
//                   height: 300,
//                   color: Colors.teal,
//                 ),
//               ],
//             ),
//             Center(
//               child: Padding(
//                 padding: const EdgeInsets.all(20.0),
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     SizedBox(height: 50,),
//                     Image.asset("assets/images/bidbridgeicon.png",color: logoColor,),
//                     Text(
//                       'Welcome to Bidbridge',
//                       style: TextStyle(fontSize: 24,color: logoTitleColor),
//                     ),
//                     SizedBox(height: 20),
//                     Card(
//                       child: Column(
//                         children:  [

//                           TextField(
//                             decoration: InputDecoration(
//                               labelText: 'User Name',
//                               contentPadding: EdgeInsets.all(8.0),
//                               suffixIcon: Icon(Icons.account_circle_outlined),
//                             ),
//                           ),
//                           TextField(
//                             controller: gmailController,
//                             decoration: InputDecoration(
//                               labelText: 'Email Address',
//                               contentPadding: EdgeInsets.all(8.0),
//                               suffixIcon: Icon(Icons.email_outlined),
//                             ),
//                           ),
//                           SizedBox(height: 5),
//                           TextField(
//                             decoration: InputDecoration(
//                               labelText: 'Password',
//                               contentPadding: EdgeInsets.all(8.0),
//                               suffixIcon: Icon(Icons.lock),
//                             ),
//                             obscureText: true,
//                           ),

//                           SizedBox(height: 10,),
//                           FloatingActionButton(
//                             onPressed: () {
//                               LoginApiHandler.checkUserRegistration(gmailController.text,context);
//                             },
//                             child: Icon(Icons.arrow_forward),
//                             backgroundColor: Colors.teal,
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(50.0), // Set the border radius as needed
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                     SizedBox(height: 20),
//                     Column(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       children: [
//                         SizedBox(
//                           width:250,
//                           child: ElevatedButton(
//                             onPressed: () async{
//                               await GoogleSignInApi.signIn(context);
//                             },
//                             child: Text('Login With Google',
//                               style: TextStyle(color: Colors.white),),
//                             style: ElevatedButton.styleFrom(
//                               backgroundColor: Colors.red,
//                               shape: RoundedRectangleBorder(
//                                 borderRadius: BorderRadius.circular(15.0), // Set the border radius as needed
//                               ),
//                             ),
//                           ),
//                         ),
//                         SizedBox(height: 10),
//                         SizedBox(
//                           width:250,
//                           child: ElevatedButton(
//                             onPressed: () {
//                               LinkedInSignInApi.signin(context);
//                             },
//                             child: Text('Login With Linkedin',
//                               style: TextStyle(color: Colors.white),),
//                             style: ElevatedButton.styleFrom(
//                               backgroundColor: Colors.blue,
//                               shape: RoundedRectangleBorder(
//                                 borderRadius: BorderRadius.circular(15.0), // Set the border radius as needed
//                               ),
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                     SizedBox(height: 20),
//                     Row(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       children: [
//                         Text('You have an account?'),
//                         TextButton(
//                           onPressed: () {
//                             Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginScreen()));
//                           },
//                           child: Text('Sign in',style: TextStyle(color: Colors.teal),),
//                         ),
//                       ],
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
               SizedBox(
                    height: MediaQuery.of(context).size.height*.11,
                  ),
                      const Text(
                    'Lets create your account!',
                    style: TextStyle(
                      color: Color(0xff770737),
                      fontSize: 26,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const Text(
                    'We are glad to see you!',
                    style: TextStyle(
                      color: Colors.black,
                      // fontSize: 17,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(
                    height: 32,
                  ),

                   Container(
                  height: 40,
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  child: TabBar(
                      dividerColor: Colors.transparent,
                      labelPadding: EdgeInsets.zero,
                      controller: tabController,
                      indicatorColor: Colors.transparent,
                      tabs: [
                        TabBarItem(
                          title: 'Freelancer',
                          isSelected: tabController.index == 0,
                          selectedColor: Colors.white,
                        ),
                        TabBarItem(
                          title: 'Employer',
                          isSelected: tabController.index == 1,
                          selectedColor: Colors.white,
                        ),
                      ]),
                ),
             
            
          
          const SizedBox(
            height: 36,
          ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                 
              
                  PrimaryTextField(
                    prefixIcon: const Icon(
                      Icons.email,
                      size: 26,
                      color: Color(0xff770737),
                    ),
                    controller: gmailController,
                    text: 'Email address',
                  ),
                  SizedBox(
                    height: 16,
                  ),
                  PrimaryTextField(
                    prefixIcon: const Icon(
                      Icons.person,
                      size: 26,
                      color: Color(0xff770737),
                    ),
                    controller: nameController,
                    text: 'Name',
                  ),
                  SizedBox(
                    height: 16,
                  ),
                  PrimaryTextField(
                    prefixIcon: const Icon(
                      Icons.lock,
                      size: 26,
                      color: Color(0xff770737),
                    ),
                    controller: passwordController,
                    text: 'Password',
                  ),

                    SizedBox(
                    height: 16,
                  ),
                  PrimaryTextField(
                    prefixIcon: const Icon(
                      Icons.lock,
                      size: 26,
                      color: Color(0xff770737),
                    ),
                    controller: retypeController,
                    text: ' Retype Password',
                  ),
                  SizedBox(
                    height: 44,
                  ),
                  SizedBox(
                    height: 48,
                    width: MediaQuery.of(context).size.width,
                    child: ElevatedButton(
                      onPressed: () {
                        LoginApiHandler.checkUserRegistration(
                            gmailController.text, context);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xff770737),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                              6.0), // Set the border radius as needed
                        ),
                      ),
                      child: const Text(
                        'Sign Up',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    height: 48,
                    width: MediaQuery.of(context).size.width,
                    child: ElevatedButton(
                      onPressed: () {
                        GoogleSignInApi.signIn(context);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange.shade500,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                              6.0), // Set the border radius as needed
                        ),
                      ),
                      child: const Text(
                        'Login With Google',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 22,
                  ),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>  LoginScreen()));
                    },
                    child: const Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Have an account? ',
                          style: TextStyle(
                            color: Color(0xFF828A89),
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        Text(
                          'Sign In!',
                          style: TextStyle(
                            color: Color(0xff770737),
                            // fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
