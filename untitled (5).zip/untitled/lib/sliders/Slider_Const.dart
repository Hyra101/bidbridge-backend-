
final List<String> lowerSliderImages =[
  "assets/slider/lowerSlider/1.jpg",
  "assets/slider/lowerSlider/2.jpg",
  "assets/slider/lowerSlider/3.jpg",
  "assets/slider/lowerSlider/4.jpg",


];
final List<String> upperSliderImages =[
  "assets/slider/upperSlider/img3.jpg",
  "assets/slider/upperSlider/img2.jpg",
  "assets/slider/upperSlider/img1.jpg",
];

  // "assets/slider/upperSlider/4.jpg",
  // "assets/slider/upperSlider/5.jpg",
  // "assets/slider/upperSlider/6.png",