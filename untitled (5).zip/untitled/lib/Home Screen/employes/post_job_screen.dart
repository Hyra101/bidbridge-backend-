import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class PostJobScreen extends StatefulWidget {
  const PostJobScreen({super.key});

  @override
  State<PostJobScreen> createState() => _PostJobScreenState();
}

class _PostJobScreenState extends State<PostJobScreen> {
  TextEditingController titleController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  TextEditingController minSalaryController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();
  TextEditingController maxSalaryController = TextEditingController();

  final _categories = <String>[
    'Accounting and Finance',
    'Clerical and Data entry',
    'Counseling',
    'Court Administration',
    'Human Resources',
    'Investigative',
    'IT and Computers',
    'Law Enforcement',
    'Management',
    'Miscellaneous',
    'Public Relations',
  ];

  String? _category;

  final _types = <String>[
    'Full Time',
    'Part Time',
    'Frreelance',
    'Internship',
    'Temporary',
  ];

  String? _type;

    File? _image;
  final picker = ImagePicker();
  Future<void> _pickImage() async {
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
      } else {
        print('No image selected.');
      }
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        elevation: 1,
        title: Text('Post a Job'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Job Title',
                style: TextStyle(
                    fontSize: 13,
                    color: Color(0xFF0C253F),
                   ),
              ),
              SizedBox(
                height: 6,
              ),
              // PrimaryTextField(controller: titleController, text: ''),
              TextField(
                controller: titleController,
                decoration: InputDecoration(
                    hintText: 'Job title',
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(
                        color: Colors.black12,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(
                        color: Colors.black12,
                      ),
                    ),
                    hintStyle:
                        TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
                    isDense: true),
              ),
              SizedBox(
                height: 14,
              ),
              Text(
                'Job Category',
                style: TextStyle(fontSize: 13, color: Color(0xFF0C253F),
               ),
              ),
              SizedBox(
                height: 6,
              ),
              DropdownButtonFormField<String>(
                hint: Text('Select job category'),
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
                decoration: InputDecoration(
                    // contentPadding: EdgeInsets.symmetric(
                    //     vertical:
                    //         MediaQuery.of(context).size.height * 0.01,
                    //     horizontal: 9),
                    // prefixIcon: const Icon(Icons.category, color: Colors.black),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(
                        color: Colors.black12,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(
                        color: Colors.black12,
                      ),
                    ),
                    hintStyle: const TextStyle(
                      color: Color(0xFF828A89),
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                    ),
                    isDense: true),
                value: _category,
                onChanged: (value) {
                  setState(() {
                    _category = value;
                  });
                },
                items: _categories
                    .map(
                      (e) => DropdownMenuItem(
                        value: e,
                        child: Text(
                          e,
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.w400,color: Color(0xFF0C253F)),
                        ),
                      ),
                    )
                    .toList(),
              ),
              SizedBox(
                height: 14,
              ),
              Text(
                'Job Type',
                style: TextStyle(fontSize: 13, color: Color(0xFF0C253F),
               ),
              ),
              SizedBox(
                height: 6,
              ),
              DropdownButtonFormField<String>(
                // ignore: prefer_const_constructors
                hint: Text('Select job type'),
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
                decoration: InputDecoration(
                    // contentPadding: EdgeInsets.symmetric(
                    //     vertical:
                    //         MediaQuery.of(context).size.height * 0.01,
                    //     horizontal: 9),
                    // prefixIcon: const Icon(Icons.category, color: Colors.black),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(
                        color: Colors.black12,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(
                        color: Colors.black12,
                      ),
                    ),
                    hintStyle: const TextStyle(
                      color: Color(0xFF828A89),
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                    ),
                    isDense: true),
                value: _type,
                onChanged: (value) {
                  setState(() {
                    _type = value;
                  });
                },
                items: _types
                    .map(
                      (e) => DropdownMenuItem(
                        value: e,
                        child: Text(
                          e,
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.w400,color: Color(0xFF0C253F)),
                        ),
                      ),
                    )
                    .toList(),
              ),
        
              SizedBox(
                height: 14,
              ),
              Text(
                'Address',
                style: TextStyle(fontSize: 13, color: Color(0xFF0C253F),
               ),
              ),
              SizedBox(
                height: 6,
              ),
               TextField(
                controller: addressController,
                decoration: InputDecoration(
                    hintText: 'Address',
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(
                        color: Colors.black12,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(
                        color: Colors.black12,
                      ),
                    ),
                    hintStyle:
                        TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
                    isDense: true),
              ),
              
              SizedBox(
                height: 14,
              ),
              Text(
                'Salary',
                style: TextStyle(fontSize: 13, color: Color(0xFF0C253F),
               ),
              ),
              SizedBox(
                height: 6,
              ),
        
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 144,
                    child:  TextField(
                keyboardType: TextInputType.number,
                controller: minSalaryController,
                decoration: InputDecoration(
                    hintText: 'Min                 Usd',
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(
                        color: Colors.black12,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(
                        color: Colors.black12,
                      ),
                    ),
                    hintStyle:
                        TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
                    isDense: true),
              ),
              
                  ),
                   Container(
                    width: 144,
                    child:  TextField(
                controller: maxSalaryController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                    hintText: 'Max                 Usd',
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(
                        color: Colors.black12,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(
                        color: Colors.black12,
                      ),
                    ),
                    hintStyle:
                        TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
                    isDense: true),
              ),
              
                  )
                ],
              ),
               SizedBox(
                height: 14,
              ),
              Text(
                'Job Description',
                style: TextStyle(fontSize: 13, color: Color(0xFF0C253F),
               ),
              ),
              SizedBox(
                height: 6,
              ),
        
               TextField(
                             controller: descriptionController,maxLines: 5,
                             decoration: InputDecoration(
               hintText: 'Description....',
               enabledBorder: OutlineInputBorder(
                 borderRadius: BorderRadius.circular(8),
                 borderSide: const BorderSide(
                   color: Colors.black12,
                 ),
               ),
               focusedBorder: OutlineInputBorder(
                 borderRadius: BorderRadius.circular(8),
                 borderSide: const BorderSide(
                   color: Colors.black12,
                 ),
               ),
               hintStyle:
                   TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
               isDense: true),
                           ),

                           SizedBox(
                            height: 18,
                           ),
        
                           InkWell(

                            onTap: () {
                             _pickImage(); 
                            },
                             child: Container(
                              height: MediaQuery.of(context).size.height*.24,
                              width: double.infinity,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(9),

                                color: Colors.grey.shade300,
                              ),
                              child:_image==null? Center(child: Icon(Icons.image,size: 36,color: Colors.black38,)):
                              
                               ClipRRect(
                                borderRadius: BorderRadius.circular(9),
                                 child: Image.file(
                                                       _image!,
                                                       // height: 150,
                                                       fit: BoxFit.cover,
                                                     ),
                               ),
                             ),
                           ),
                              SizedBox(
                    height: 44,
                  ),
                  SizedBox(
                    height: 52,
                    width: MediaQuery.of(context).size.width,
                    child: ElevatedButton(
                      onPressed: () {
                       
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xff770737),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                              6.0), // Set the border radius as needed
                        ),
                      ),
                      child: const Text(
                        'Post a Job',
                        style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 16),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),


            ],
          ),
        ),
      ),
    );
  }
}
