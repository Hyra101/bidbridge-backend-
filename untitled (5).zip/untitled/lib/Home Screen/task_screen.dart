import 'package:flutter/material.dart';
import 'package:untitled/projects/Project_Details.dart';

class TasksScreen extends StatefulWidget {
  const TasksScreen({super.key});

  @override
  State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen> {
  List<String> names = [
    'Sandy Forest',
    'Nicholy arzov',
    'Tom Smith',
  ];

  List<String> titles = [
    'Food Delivery Mobile Application',
    '2000 words English to German'
        'Fix Python Selenium code',
    'Wordpress Theme Installation',
    'PHP core website fixes',
  ];
  List<String> prices = [
    'Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate strategy foster',
    '2500',
    '3000',
    '34',
  ];
  List<String> time = [
    '2',
    '5',
    '23',
    '33',
    '54',
  ];
  List<String> fixedPrice = [
    '\$2,500 - \$4,500',
    '\$80 - \$200',
    '\$50 - \$100',
    '\$100 - \$300',
    '\$60 - \$140',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'Tasks',
          style: TextStyle(fontWeight: FontWeight.w600, fontSize: 19),
        ),
        elevation: 1,
      ),
      body: ListView.builder(
        itemCount: 4,
        physics: BouncingScrollPhysics(),
        shrinkWrap: true,
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Card(
              color: Colors.white,
              elevation: 2,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(6)),
              child: Container(
                margin: EdgeInsets.symmetric(vertical: 7),
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                width: double.infinity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      titles[index],
                      style:
                          TextStyle(fontWeight: FontWeight.w500, fontSize: 15),
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.access_time,
                          size: 16,
                          color: Color(0x99131A22),
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        Text('${time[index]} min ago')
                      ],
                    ),
                    SizedBox(
                      height: 6,
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.location_on_outlined,
                          size: 16,
                          color: Color(0x99131A22),
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        Text('Online')
                      ],
                    ),
                    SizedBox(
                      height: 8,
                    ),
                    Text(
                      'Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate strategy foster',
                      style: TextStyle(color: Color(0x99131A22), fontSize: 13),
                    ),
                    SizedBox(
                      height: 6,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Fixed Price',
                          style: TextStyle(
                              color: Colors.green,
                              // fontSize: 13
                              fontWeight: FontWeight.bold),
                        ),
                        Text(
                          '\$${fixedPrice[index]}',
                          style: TextStyle(
                              fontWeight: FontWeight.w500, fontSize: 12),
                        ),
                      ],
                    ),
                    
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            // width: double.infinity,
                            padding:
                                EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                            margin: EdgeInsets.symmetric(horizontal: 3),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                color: Colors.grey.shade200),
                            child: Center(
                                child: Text(
                              'iOS',
                              style: TextStyle(color: Colors.blueAccent.shade700),
                            )),
                          ),
                            Container(
                            // width: double.infinity,
                            padding:
                                EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                            margin: EdgeInsets.symmetric(horizontal: 3),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                color: Colors.grey.shade200),
                            child: Center(
                                child: Text(
                              'Android',
                              style: TextStyle(color: Colors.blueAccent.shade700),
                            )),
                          ), Container(
                            // width: double.infinity,
                            padding:
                                EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                            margin: EdgeInsets.symmetric(horizontal: 3),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                color: Colors.grey.shade200),
                            child: Center(
                                child: Text(
                              'mobile apps',
                              style: TextStyle(color: Colors.blueAccent.shade700),
                            )),
                          ), Container(
                            // width: double.infinity,
                            padding:
                                EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                            margin: EdgeInsets.symmetric(horizontal: 3),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                color: Colors.grey.shade200),
                            child: Center(
                                child: Text(
                              'design',
                              style: TextStyle(color: Colors.blueAccent.shade700),
                            )),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 13,
                    ),
                   Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                     children: [
                       InkWell(
                        onTap: () {
                           Navigator.push(context,
                  MaterialPageRoute(builder: (context) => ProjectDetailsScreen(projectId: '',)));
                        },
                         child: Container(
                                width: MediaQuery.of(context).size.width * .5,
                                padding:
                                    EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                                decoration: BoxDecoration(
                                    color: Color(0xff770737),
                                    borderRadius: BorderRadius.circular(6)),
                                child: Center(
                                  child: Text(
                                    'Bid Now',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16),
                                  ),
                                ),
                              ),
                       ),
                     ],
                   ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
