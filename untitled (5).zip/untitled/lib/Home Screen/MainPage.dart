import 'package:flutter/material.dart';
import 'package:untitled/Home%20Screen/home_screen.dart';
import 'package:untitled/Home%20Screen/recent_tasks/recent_tasks_screen.dart';
import 'package:untitled/animation.dart';
import 'package:untitled/chats/ChatListScreen.dart';
import 'package:untitled/profile/profile_screen.dart';
import 'package:untitled/projects/BookmarkProjects.dart';
import 'task_screen.dart';

class Mainpage extends StatefulWidget {
  const Mainpage({super.key});

  @override
  State<Mainpage> createState() => _MainpageState();
}

class _MainpageState extends State<Mainpage> {
  @override
  Widget build(BuildContext context) {
    Widget _buildTabBarView() {
      return TabBarView(
        children: [
          HomeScreen(),
          ChatListScreen(),
          BookmarkedProjectsScreen(),
          TasksScreen(),
          ProfileScreen(),
        ],
      );
    }
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        body: _buildTabBarView(),
        bottomNavigationBar: TabBar(
          tabs: [
            Tab(icon: Icon(Icons.home,color: Color(0xff770737),)),
            Tab(icon: Icon(Icons.message,color: Color(0xff770737),)),
            Tab(icon: Icon(Icons.bookmark,color: Color(0xff770737),)),
            Tab(icon: Icon(Icons.work,color: Color(0xff770737),)),
            Tab(icon: Icon(Icons.person_2,color: Color(0xff770737),)),
          ],
          indicatorColor: whiteColor,
        ),
      ),
    );
  }
}
