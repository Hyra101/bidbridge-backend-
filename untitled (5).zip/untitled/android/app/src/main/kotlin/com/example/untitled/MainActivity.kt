package com.example.bidpro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
