import 'package:flutter/material.dart';
import 'package:untitled/Home%20Screen/job/Job_Screen.dart';
import 'package:untitled/Home%20Screen/recent_tasks/recent_tasks_screen.dart';
import 'package:untitled/Home%20Screen/task_screen.dart';

import '../../Navigation Drawer/companies.dart';
import '../../projects/viewProjects_screen.dart';

class WorkScreen extends StatefulWidget {
  const WorkScreen({super.key});

  @override
  State<WorkScreen> createState() => _WorkScreenState();
}

class _WorkScreenState extends State<WorkScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'Find Work',
          style: TextStyle(fontWeight: FontWeight.w600, fontSize: 19),
        ),
        elevation: 1,
      ),
      body: Column(
        children: [
          SizedBox(
            height: 20,
          ),
          WorkWidget(
            text: 'Browse Jobs',
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => JobsScreen()));
            },
          ),
          WorkWidget(
            text: 'Browse Tasks',
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => TasksScreen()));
            },
          ),
        ],
      ),
    );
  }
}

class WorkWidget extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const WorkWidget({
    super.key,
    required this.text,
    required this.onTap,
  });
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        // height: 47,
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 19),
        decoration: ShapeDecoration(
          color: Colors.white,
          shape: RoundedRectangleBorder(
            side: const BorderSide(
              width: 1,
              strokeAlign: BorderSide.strokeAlignOutside,
              color: Color(0xFFF1F1F1),
            ),
            borderRadius: BorderRadius.circular(10),
          ),
          shadows: const [
            BoxShadow(
              color: Color(0x3F000000),
              blurRadius: 4,
              offset: Offset(-1, 1),
              spreadRadius: 0,
            )
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              text,
              style: const TextStyle(
                color: Color(0x99131A22),
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
            const Icon(
              Icons.arrow_forward_ios,
              size: 21,
              color: Color(0x99131A22),
            )
          ],
        ),
      ),
    );
  }
}
