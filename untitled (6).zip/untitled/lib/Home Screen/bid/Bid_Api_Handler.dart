import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../../animation.dart';

class BidApiHandler {
  static const String baseUrl = '$appBaseUrl/bids/'; // Update with your base URL

  Future<String?> _getToken() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }

  Future<http.Response> _post(String endpoint, Map<String, dynamic> data) async {
    String? token = await _getToken();
    return await http.post(
      Uri.parse('$baseUrl$endpoint'),
      headers: {
        'Content-Type': 'application/json',
        'x-access-token': token ?? '',
      },
      body: json.encode(data),
    );
  }

  Future<http.Response> _get(String endpoint) async {
    String? token = await _getToken();
    return await http.get(
      Uri.parse('$baseUrl$endpoint'),
      headers: {
        'Content-Type': 'application/json',
        'x-access-token': token ?? '',
      },
    );
  }

  Future<http.Response> _delete(String endpoint) async {
    String? token = await _getToken();
    return await http.delete(
      Uri.parse('$baseUrl$endpoint'),
      headers: {
        'Content-Type': 'application/json',
        'x-access-token': token ?? '',
      },
    );
  }

  Future<http.Response> _patch(String endpoint, Map<String, dynamic> data) async {
    String? token = await _getToken();
    return await http.patch(
      Uri.parse('$baseUrl$endpoint'),
      headers: {
        'Content-Type': 'application/json',
        'x-access-token': token ?? '',
      },
      body: json.encode(data),
    );
  }

  // API methods

  Future<http.Response> addBid(Map<String, dynamic> taskData) {
    return _post('add', taskData);
  }

  Future<http.Response> getBidsByTaskId(String taskId) {
    return _get('get/$taskId');
  }

  Future<http.Response> getAllUserBids() {
    return _get('get');
  }

  Future<http.Response> deleteBid(String taskId) {
    return _delete('delete/$taskId');
  }

  Future<http.Response> updateBid(String taskId, Map<String, dynamic> updateData) {
    return _patch('update/$taskId', updateData);
  }
}

class Bid {
  final String? id;
  final String? bidRate;
  final String? deliveryTime;
  final Map<String, dynamic>? applicantCV;
  final double? createdAt;
  final String? taskId;
  final String? userId;
  final Map<String, dynamic>? review;

  Bid({
    this.id,
    this.bidRate,
    this.deliveryTime,
    this.applicantCV,
    this.createdAt,
    this.taskId,
    this.userId,
    this.review,
  });

  // Factory constructor to create a Bid object from JSON
  factory Bid.fromJson(Map<String, dynamic> json) {
    return Bid(
      id: json['_id'],
      bidRate: json['bidRate'],
      deliveryTime: json['deliveryTime'],
      applicantCV: json['applicantCV'] != null
          ? Map<String, dynamic>.from(json['applicantCV'])
          : null,
      createdAt: json['createdAt'] != null
          ? double.parse(json['createdAt'].toString())
          : null,
      taskId: json['taskId'],
      userId: json['userId'],
      review: json['review'] != null
          ? Map<String, dynamic>.from(json['review'])
          : null,
    );
  }

  // Method to convert a Bid object to JSON
  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'bidRate': bidRate,
      'deliveryTime': deliveryTime,
      'applicantCV': applicantCV,
      'createdAt': createdAt,
      'taskId': taskId,
      'userId': userId,
      'review': review,
    };
  }

  // Method to create a list of Bid objects from a list of JSON objects
  static List<Bid> fromList(List<dynamic> list) {
    return list.map((item) => Bid.fromJson(item)).toList();
  }
}
