import 'dart:convert';

import 'package:flutter/material.dart';

import '../../login_screen/RegisterApiHandler.dart';
import 'Job_Api_Handler.dart';
import 'Job_Details_Screen.dart';

class JobsScreen extends StatefulWidget {
  const JobsScreen({super.key});

  @override
  State<JobsScreen> createState() => _JobsScreenState();
}

class _JobsScreenState extends State<JobsScreen> {
  late Future<List<Job>> tasksFuture; // Define the future to hold the tasks
  final JobApiHandler _apiHandler = JobApiHandler();
  UserApiHandler userApiHandler = UserApiHandler();
  List<String> bookMarkedIds = []; // State variable to hold bookmarked job

  @override
  void initState() {
    super.initState();
    _initializeData();
    tasksFuture = _getAllTasks(); // Fetch the tasks when the screen is initialized
  }

  Future<void> _initializeData() async {
    var _userDetails = await userApiHandler.getUserDetails();
    setState(() {
      bookMarkedIds = List<String>.from(_userDetails!["user"]['data']["bookmarkedJobs"] ?? []);
    });
  }

  Future<List<Job>> _getAllTasks() async {
    final response = await _apiHandler.getAllTasks(); // Adjust this to your actual API handler method
    if (response.statusCode == 200) {
      final responseData = jsonDecode(response.body);
      if (responseData['success']) {
        print(responseData);
        return Job.fromList(responseData['jobs']); // Extract tasks from 'data' field
      } else {
        _showSnackBar('Failed to retrieve all tasks');
        return [];
      }
    } else {
      _showSnackBar('Failed to retrieve all tasks');
      return [];
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> updateBookMark(String jobId) async {
    var _userDetails = await userApiHandler.getUserDetails();
    List<dynamic> bookMarkedIds=[];
    Map<String, dynamic> data={ } ;
    try{
      bookMarkedIds = _userDetails!["user"]['data']["bookmarkedJobs"] ?? [];
      print("Working ");
      data = _userDetails["user"]['data'];
    }
    catch(e){

    }
    if (!data.containsKey("bookmarkedJobs")) {
      data['bookmarkedJobs'] = [];
    }


    if (bookMarkedIds.contains(jobId)) {
      bookMarkedIds.remove(jobId);
    } else {
      bookMarkedIds.add(jobId);
    }
    data["bookmarkedJobs"] = bookMarkedIds;
    await userApiHandler.addBookMark(data);
    setState(() {
      _initializeData();
      tasksFuture = _getAllTasks(); // Refresh the list after updating bookmark
    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'Jobs',
          style: TextStyle(fontWeight: FontWeight.w600, fontSize: 19),
        ),
        elevation: 1,
      ),
      body: FutureBuilder<List<Job>>(
        future: tasksFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator()); // Show a loading indicator while waiting for the tasks
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}')); // Show an error message if there's an issue
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No bookmarked jobs found.')); // Show a message if no tasks are found
          } else {
            final tasks = snapshot.data!;
            return ListView.builder(
              itemCount: tasks.length,
              physics: BouncingScrollPhysics(),
              shrinkWrap: true,
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              itemBuilder: (context, index) {
                final task = tasks[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Card(
                    color: Colors.white,
                    elevation: 3,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    child: Container(
                      margin: EdgeInsets.symmetric(vertical: 10),
                      padding: EdgeInsets.symmetric(horizontal: 15, vertical: 12),
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                task.title!, // Display the task name
                                style: TextStyle(
                                    fontWeight: FontWeight.w600, fontSize: 16),
                              ),
                              IconButton(
                                icon: Icon(
                                  bookMarkedIds.contains(task.id)
                                      ? Icons.bookmark
                                      : Icons.bookmark_border,
                                  color: Colors.red,
                                ),
                                onPressed: () {
                                  updateBookMark(task.id!);
                                },
                              ),
                            ],
                          ),
                          SizedBox(height: 6),
                          Row(
                            children: [
                              Icon(
                                Icons.access_time,
                                size: 16,
                                color: Colors.grey.shade600,
                              ),
                              SizedBox(width: 5),
                              Text('${DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(int.parse(task.createdAt!.toStringAsFixed(0)))).inDays} days ago') // Display the number of days since the task was posted
                            ],
                          ),
                          SizedBox(height: 8),
                          Row(
                            children: [
                              Icon(
                                Icons.location_on_outlined,
                                size: 16,
                                color: Colors.grey.shade600,
                              ),
                              SizedBox(width: 5),
                              Text(task.location!), // Display the task location
                            ],
                          ),
                          SizedBox(height: 10),
                          Text(
                            task.description!, // Display the task description
                            style: TextStyle(color: Colors.black87, fontSize: 13),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis, // Limit description to 2 lines
                          ),
                          SizedBox(height: 10),
                          Align(
                            alignment: Alignment.center,
                            child: InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => JobDetailsScreen(job: task), // Navigate to JobDetailsScreen
                                  ),
                                );
                              },
                              child: Container(
                                width: MediaQuery.of(context).size.width * .5,
                                padding: EdgeInsets.symmetric(
                                    vertical: 12, horizontal: 16),
                                decoration: BoxDecoration(
                                    color: Color(0xff770737),
                                    borderRadius: BorderRadius.circular(6)),
                                child: Center(
                                  child: Text(
                                    'Apply Now',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            );
          }
        },
      ),

    );
  }
}



class Job {
  final String? id;
  final String? title;
  final String? type;
  final String? category;
  final String? location;
  final String? salary;
  final String? tags;
  final String? description;
  final double? createdAt;
  final Map<String, dynamic>? companyLogo;
  final Map<String, dynamic>? data;
  final String? userId;

  Job({
    this.id,
    this.title,
    this.type,
    this.category,
    this.location,
    this.salary,
    this.tags,
    this.description,
    this.createdAt,
    this.companyLogo,
    this.data,
    this.userId,
  });

  // Factory constructor to create a Job object from JSON
  factory Job.fromJson(Map<String, dynamic> json) {
    return Job(
      id: json['_id'],
      title: json['title'],
      type: json['type'],
      category: json['category'],
      location: json['location'],
      salary: json['salary'],
      tags: json['tags'],
      description: json['description'],
      createdAt: double.parse(json['createdAt'].toString()),
      companyLogo: json['companyLogo'] != null
          ? Map<String, dynamic>.from(json['companyLogo'])
          : null,
      data: json['data'] != null ? Map<String, dynamic>.from(json['data']) : null,
      userId: json['userId'],
    );
  }

  // Method to convert a Job object to JSON
  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'title': title,
      'type': type,
      'category': category,
      'location': location,
      'salary': salary,
      'tags': tags,
      'description': description,
      'createdAt': createdAt,
      'companyLogo': companyLogo,
      'data': data,
      'userId': userId,
    };
  }

  // Method to create a list of Job objects from a list of JSON objects
  static List<Job> fromList(List<dynamic> list) {
    return list.map((item) => Job.fromJson(item)).toList();
  }
}
