import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart'; // Add this import for file picker
import '../../login_screen/RegisterApiHandler.dart';
import '../job_application/JobApplicationApiHandler.dart';
import 'Job_Screen.dart';

class JobDetailsScreen extends StatefulWidget {
  final Job job;

  JobDetailsScreen({super.key, required this.job});

  @override
  State<JobDetailsScreen> createState() => _JobDetailsScreenState();
}

class _JobDetailsScreenState extends State<JobDetailsScreen> {
  bool bidAlreadySent = false;
  late Future<List<JobApplication>> tasksFuture;
  final JobApplicationApiHandler _jobApplicationApiHandler = JobApplicationApiHandler();
  UserApiHandler userApiHandler = UserApiHandler();

  File? _selectedCV; // Variable to store the selected PDF file

  Future<List<JobApplication>> _getJobApplications(String jobId) async {
    userDetails =await userApiHandler.getUserDetails();

    final response = await _jobApplicationApiHandler.getJobApplicationByJobIdAndUserId(jobId);
    if (response.statusCode == 200) {
      final responseData = jsonDecode(response.body);
      if (responseData['success']) {
        return JobApplication.fromList(responseData['jobApplications']);
      } else {
        _showSnackBar('Failed to retrieve all tasks');
        return [];
      }
    } else {
      _showSnackBar('Failed to retrieve all tasks');
      return [];
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  late Map<String, dynamic>? userDetails ;
  @override
  void initState() {
    super.initState();
    tasksFuture = _getJobApplications(widget.job.id!);

  }

  Future<void> _pickCVFile() async {
    // Open the file picker to select a PDF file
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'], // Restrict file type to PDF
    );

    if (result != null && result.files.isNotEmpty) {
      setState(() {
        _selectedCV = File(result.files.single.path!);
      });
      _showSnackBar('CV selected: ${result.files.single.name}');
    } else {
      _showSnackBar('No file selected');
    }
  }

  Future<void> _applyForJob() async {
    if (_selectedCV == null) {
      _showSnackBar('Please select a CV before applying');
      return;
    }

    Map<String, dynamic> applicationData = {
      'jobId': widget.job.id!,
      "applicantName": userDetails!["user"]['name'] ?? 'N/A',
      "applicantEmail": userDetails!["user"]['email'] ?? 'N/A',
    };

    // Pass the correct file path
    final response = await _jobApplicationApiHandler.addJobApplication(
      applicationData,
      filePath: _selectedCV!.path,
    );

    if (response.statusCode == 200) {
      final responseData =await jsonDecode(response.body);
      if (responseData['success']) {
        _showSnackBar('Application submitted successfully');
        setState(() {
          bidAlreadySent = true;
        });
      } else {
        _showSnackBar('Failed to submit application');
      }
    } else {
      _showSnackBar('Failed to submit application');
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Job Details'),
        backgroundColor: Color(0xff770737),
      ),
      body: FutureBuilder(
        future: tasksFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else {
            final tasks = snapshot.data!;
            return SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.job.title!,
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black87),
                  ),
                  SizedBox(height: 12),
                  Text(
                    widget.job.description!,
                    style: TextStyle(fontSize: 16, color: Colors.black54),
                  ),
                  SizedBox(height: 16),
                  Row(
                    children: [
                      Icon(Icons.location_on, color: Colors.black54, size: 20),
                      SizedBox(width: 8),
                      Text(
                        'Location: ${widget.job.location}',
                        style: TextStyle(fontSize: 16, color: Colors.black87),
                      ),
                    ],
                  ),
                  SizedBox(height: 12),
                  Row(
                    children: [
                      Icon(Icons.attach_money, color: Colors.black54, size: 20),
                      SizedBox(width: 8),
                      Text(
                        'Budget: \$${widget.job.salary}',
                        style: TextStyle(fontSize: 16, color: Colors.black87),
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  // Button to pick CV file
                  Align(
                    alignment: Alignment.center,
                    child: ElevatedButton(
                      onPressed: _pickCVFile,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blueGrey, // Background color
                        padding: EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6),
                        ),
                      ),
                      child: Text(
                        'Select CV',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                    ),
                  ),
                  SizedBox(height: 10),
                  // Apply Now Button
                  Align(
                    alignment: Alignment.center,
                    child: ElevatedButton(
                      onPressed: tasks.isNotEmpty || bidAlreadySent ? null : _applyForJob,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0xff770737), // Background color
                        padding: EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6),
                        ),
                      ),
                      child: Text(
                        tasks.isNotEmpty || bidAlreadySent ? 'Already Applied' : 'Apply Now',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                    ),
                  ),
                ],
              ),
            );
          }
        },
      ),
    );
  }
}
