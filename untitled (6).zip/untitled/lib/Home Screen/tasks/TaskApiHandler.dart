import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../../animation.dart';

class TasksApiHandler {
  static const String baseUrl = '$appBaseUrl/tasks/'; // Update with your base URL

  Future<String?> _getToken() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }

  Future<http.Response> _post(String endpoint, Map<String, dynamic> data) async {
    String? token = await _getToken();
    return await http.post(
      Uri.parse('$baseUrl$endpoint'),
      headers: {
        'Content-Type': 'application/json',
        'x-access-token': token ?? '',
      },
      body: json.encode(data),
    );
  }

  Future<http.Response> _get(String endpoint) async {
    String? token = await _getToken();
    return await http.get(
      Uri.parse('$baseUrl$endpoint'),
      headers: {
        'Content-Type': 'application/json',
        'x-access-token': token ?? '',
      },
    );
  }

  Future<http.Response> _delete(String endpoint) async {
    String? token = await _getToken();
    return await http.delete(
      Uri.parse('$baseUrl$endpoint'),
      headers: {
        'Content-Type': 'application/json',
        'x-access-token': token ?? '',
      },
    );
  }

  Future<http.Response> _patch(String endpoint, Map<String, dynamic> data) async {
    String? token = await _getToken();
    return await http.patch(
      Uri.parse('$baseUrl$endpoint'),
      headers: {
        'Content-Type': 'application/json',
        'x-access-token': token ?? '',
      },
      body: json.encode(data),
    );
  }

  // API methods

  Future<http.Response> addTask(Map<String, dynamic> taskData) {
    return _post('add', taskData);
  }

  Future<http.Response> getUserTasks() {
    return _get('get/user');
  }

  Future<http.Response> getAllTasks() {
    return _get('get');
  }

  Future<http.Response> deleteTask(String taskId) {
    return _delete('delete/$taskId');
  }

  Future<http.Response> updateTask(String taskId, Map<String, dynamic> updateData) {
    return _patch('update/$taskId', updateData);
  }

  Future<Map<String, dynamic>> fetchTaskById(String taskId) async {
    final response = await http.get(Uri.parse('http://192.168.100.84:3000/tasks/task/$taskId'));

    if (response.statusCode == 200) {
      // Parse the JSON
      final data = json.decode(response.body);
      return data['task']; // Assuming the JSON response has a 'task' key
    } else {
      throw Exception('Failed to load task');
    }
  }

}
