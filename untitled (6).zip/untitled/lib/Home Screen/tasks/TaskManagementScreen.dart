import 'package:flutter/material.dart';

import 'TaskApiHandler.dart';

class TaskManagementScreen extends StatefulWidget {
  @override
  _TaskManagementScreenState createState() => _TaskManagementScreenState();
}

class _TaskManagementScreenState extends State<TaskManagementScreen> {
  final TasksApiHandler _apiHandler = TasksApiHandler();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Task Management'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: _addTask,
              child: Text('Add Task'),
            ),
            ElevatedButton(
              onPressed: _getUserTasks,
              child: Text('Get User Tasks'),
            ),
            ElevatedButton(
              onPressed: _getAllTasks,
              child: Text('Get All Tasks'),
            ),
            ElevatedButton(
              onPressed: _deleteTask,
              child: Text('Delete Task'),
            ),
            ElevatedButton(
              onPressed: _updateTask,
              child: Text('Update Task'),
            ),
          ],
        ),
      ),
    );
  }

  void _addTask() async {
    Map<String, dynamic> taskData = {
      "title": "New Task",
      "type": "Type A",
      "category": "Category X",
      "location": "Location Y",
      "budget": "100",
      "requiredSkills": "Skill 1, Skill 2",
      "description": "Task description here",
    };

    final response = await _apiHandler.addTask(taskData);
    if (response.statusCode == 200) {
      _showSnackBar('Task added successfully');
    } else {
      _showSnackBar('Failed to add task');
    }
  }

  void _getUserTasks() async {
    final response = await _apiHandler.getUserTasks();
    if (response.statusCode == 200) {
      print(response.body);
      _showSnackBar('User tasks retrieved successfully');
    } else {
      _showSnackBar('Failed to retrieve user tasks');
    }
  }

  void _getAllTasks() async {
    final response = await _apiHandler.getAllTasks();
    if (response.statusCode == 200) {
      print(response.body);
      _showSnackBar('All tasks retrieved successfully');
    } else {
      _showSnackBar('Failed to retrieve all tasks');
    }
  }

  void _deleteTask() async {
    final response = await _apiHandler.deleteTask('task-id');
    if (response.statusCode == 200) {
      _showSnackBar('Task deleted successfully');
    } else {
      _showSnackBar('Failed to delete task');
    }
  }

  void _updateTask() async {
    Map<String, dynamic> updateData = {
      "title": "Updated Task",
      "description": "Updated description",
    };

    final response = await _apiHandler.updateTask('task-id', updateData);
    if (response.statusCode == 200) {
      _showSnackBar('Task updated successfully');
    } else {
      _showSnackBar('Failed to update task');
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}
