import 'package:flutter/material.dart';
import 'package:untitled/Home%20Screen/employes/post_job_screen.dart';

import 'post_task_screen.dart';

class EmployrScreen extends StatefulWidget {
  const EmployrScreen({super.key});

  @override
  State<EmployrScreen> createState() => _EmployrScreenState();
}

class _EmployrScreenState extends State<EmployrScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'Employes',
          style: TextStyle(fontWeight: FontWeight.w600, fontSize: 19),
        ),
        elevation: 1,
      ),
      body: Column(
        children: [
          SizedBox(
            height: 20,
          ),
          WorkWidget(
            text: 'Post a Task',
            // text: 'Browse Jobs',
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => PostTaskScreen()));
            },
          ),
          WorkWidget(
            text: 'Post a Job',
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => PostJobScreen()));
            },
          ),
        ],
      ),
    );
  }
}

class WorkWidget extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const WorkWidget({
    super.key,
    required this.text,
    required this.onTap,
  });
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        // height: 47,
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 19),
        decoration: ShapeDecoration(
          color: Colors.white,
          shape: RoundedRectangleBorder(
            side: const BorderSide(
              width: 1,
              strokeAlign: BorderSide.strokeAlignOutside,
              color: Color(0xFFF1F1F1),
            ),
            borderRadius: BorderRadius.circular(10),
          ),
          shadows: const [
            BoxShadow(
              color: Color(0x3F000000),
              blurRadius: 4,
              offset: Offset(-1, 1),
              spreadRadius: 0,
            )
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              text,
              style: const TextStyle(
                color: Color(0x99131A22),
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
            const Icon(
              Icons.arrow_forward_ios,
              size: 21,
              color: Color(0x99131A22),
            )
          ],
        ),
      ),
    );
  }
}
