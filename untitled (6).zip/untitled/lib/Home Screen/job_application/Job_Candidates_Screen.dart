import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:untitled/Home%20Screen/job_application/JobApplicationApiHandler.dart';
import 'package:untitled/login_screen/RegisterApiHandler.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:open_file/open_file.dart';

import '../chat/Chat_Screen.dart';
import '../job/Job_Screen.dart';

class JobCandidatesScreen extends StatefulWidget {
  List<JobApplication> jobApplicationsList;
  Job job;
  JobCandidatesScreen({super.key, required this.jobApplicationsList, required this.job});

  @override
  State<JobCandidatesScreen> createState() => _JobCandidatesScreenState();
}

class _JobCandidatesScreenState extends State<JobCandidatesScreen> {
  UserApiHandler userApiHandler = UserApiHandler();
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
  }



  Future<void> downloadAndOpenCV( Map<String, dynamic> applicantCV) async {
    // Request storage permissions
    final status = await Permission.storage.request();

    if (status.isGranted) {
      try {
        print(applicantCV);
        final filename = applicantCV['filename'];
        final fileDataMap = applicantCV['data']; // Expecting a map here

        // Extract the list of integers from the 'data' field
        if (fileDataMap != null && filename != null) {
          // Convert the 'data' field into a List<int> if it's in the expected format
          final fileDataList = List<int>.from(fileDataMap['data'] ?? []);

          // Get the public external directory to save the file
          final directory = await getExternalStorageDirectory();
          final path = '${directory!.path}/Download'; // Use the 'Download' folder
          await Directory(path).create(recursive: true); // Create directory if not exists

          // Define the file path
          final filePath = '$path/$filename';
          print('Saving file to: $filePath'); // Debugging line

          // Save the file locally
          final file = File(filePath);
          await file.writeAsBytes(fileDataList);

          // Show snackbar message
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Downloaded successfully!'),
              duration: Duration(seconds: 2),
            ),
          );

          // Open the file
          final result = await OpenFile.open(filePath);
          print('OpenFile result: ${result.message}'); // Debugging line
        } else {
          print('No file data available.');
        }
      } catch (e) {
        print('Error: $e');

      }
    } else {
      print('Storage permission denied');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Permission denied. Please enable storage permissions.'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Manage Bidders'),
        elevation: 1,
        centerTitle: true,
      ),
      body: ListView.builder(
        itemCount: widget.jobApplicationsList.length,
        physics: BouncingScrollPhysics(),
        shrinkWrap: true,
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        itemBuilder: (context, index) {
          print(widget.jobApplicationsList[index].userId!);
          Future<Map<String, dynamic>?> userDetails = userApiHandler.getUserDetailsById(widget.jobApplicationsList[index].userId!);
          return FutureBuilder(
              future: userDetails,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator()); // Show a loading indicator while waiting for the tasks
                } else if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}')); // Show an error message if there's an issue
                } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return Center(child: Text('No tasks found.')); // Show a message if no tasks are found
                } else {
                  final userData = snapshot.data!;
                  final applicantCV = widget.jobApplicationsList[index].applicantCV;
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: Card(
                      color: Colors.white,
                      elevation: 4,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6)),
                      child: Container(
                        margin: EdgeInsets.symmetric(vertical: 7),
                        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                        width: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                CircleAvatar(
                                  radius: 36,
                                  backgroundImage: NetworkImage(imgList[Random().nextInt(imgList.length)]),
                                ),
                                SizedBox(width: 9),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      userData["user"]['name'] ?? 'N/A',
                                      style: TextStyle(fontWeight: FontWeight.w500),
                                    ),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.email,
                                          size: 21,
                                          color: Color(0x99131A22),
                                        ),
                                        SizedBox(width: 6),
                                        Text(
                                          userData["user"]['email'] ?? 'N/A',
                                          style: TextStyle(
                                            fontSize: 13,
                                            color: Color(0x99131A22),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                )
                              ],
                            ),
                            SizedBox(height: 6),
                            RatingBar.builder(
                                initialRating: 5,
                                minRating: 0,
                                direction: Axis.horizontal,
                                allowHalfRating: true,
                                itemCount: 5,
                                itemSize: 20,
                                itemPadding: const EdgeInsets.symmetric(horizontal: 2.0),
                                itemBuilder: (context, _) => const Icon(
                                  Icons.star,
                                  color: Colors.amber,
                                  size: 26,
                                ),
                                onRatingUpdate: (rating) async {}),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                InkWell(
                                  onTap: () async {
                                    if (applicantCV != null) {
                                      await downloadAndOpenCV(applicantCV);
                                    }
                                  },
                                  child: Container(
                                    width: MediaQuery.of(context).size.width * .32,
                                    padding: EdgeInsets.symmetric(vertical: 6),
                                    decoration: BoxDecoration(
                                        color: Color(0xff770737),
                                        borderRadius: BorderRadius.circular(4)),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Icon(
                                          Icons.document_scanner,
                                          color: Colors.white,
                                          size: 19,
                                        ),
                                        SizedBox(width: 4),
                                        Text(
                                          'Download CV',
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 13),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                InkWell(
                                  onTap: () async {
                                    SharedPreferences prefs = await SharedPreferences.getInstance();
                                    String userId = await prefs.getString("userId")!;
                                    Navigator.push(context, MaterialPageRoute(builder: (_) {
                                      return ChatScreen(
                                          userId: userId,
                                          reciverId: userData["user"]['_id']);
                                    }));
                                  },
                                  child: Container(
                                    width: MediaQuery.of(context).size.width * .34,
                                    padding: EdgeInsets.symmetric(vertical: 6),
                                    decoration: BoxDecoration(
                                        color: Colors.black,
                                        borderRadius: BorderRadius.circular(4)),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Icon(
                                          Icons.chat,
                                          color: Colors.white,
                                          size: 19,
                                        ),
                                        SizedBox(width: 4),
                                        Text(
                                          'Send Message',
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 13),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }
              });
        },
      ),
    );
  }

  final List<String> imgList = [
    'https://images.unsplash.com/photo-1522205408450-add114ad53fe?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=368f45b0888aeb0b7b08e3a1084d3ede&auto=format&fit=crop&w=1950&q=80',
    'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=94a1e718d89ca60a6337a6008341ca50&auto=format&fit=crop&w=1950&q=80',
    'https://images.unsplash.com/photo-1523205771623-e0faa4d2813d?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=89719a0d55dd05e2deae4120227e6efc&auto=format&fit=crop&w=1953&q=80',
  ];
}
