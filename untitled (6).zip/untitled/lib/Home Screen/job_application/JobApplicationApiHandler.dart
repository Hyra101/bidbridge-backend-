import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../../animation.dart';

class JobApplicationApiHandler {
  static const String baseUrl = '$appBaseUrl/job-applications/'; // Update with your base URL

  Future<String?> _getToken() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }



  Future<http.Response> _post(String endpoint, Map<String, dynamic> data, {String? filePath}) async {
    String? token = await _getToken();
    var request = http.MultipartRequest('POST', Uri.parse('$baseUrl$endpoint'))
      ..headers['x-access-token'] = token ?? '';

    data.forEach((key, value) {
      request.fields[key] = value.toString();
    });

    if (filePath != null) {
      // Use 'applicantCV' as the field name, matching the backend expectation
      request.files.add(await http.MultipartFile.fromPath('applicantCV', filePath));
    }

    var streamedResponse = await request.send();
    return http.Response.fromStream(streamedResponse);
  }


  Future<http.Response> _get(String endpoint) async {
    String? token = await _getToken();
    return await http.get(
      Uri.parse('$baseUrl$endpoint'),
      headers: {
        'Content-Type': 'application/json',
        'x-access-token': token ?? '',
      },
    );
  }

  // API methods

  Future<http.Response> addJobApplication(Map<String, dynamic> applicationData, {String? filePath}) {
    return _post('add', applicationData, filePath: filePath);
  }


  Future<http.Response> getJobApplicationsByUser() {
    return _get('get');
  }

  Future<http.Response> getJobApplicationsByJobIds(List<String> jobIds) {
    return _get('get/${jobIds.join(",")}');
  }

  // API method to get job applications by job ID
  Future<http.Response> getJobApplicationByJobId(String jobId) {
    return _get('get/$jobId');
  }

  // API method to get job applications by job ID
  Future<http.Response> getJobApplicationByJobIdAndUserId(String jobId) {
    return _get('getbyjobanduser/$jobId');
  }

}

class JobApplication {
  final String? id;
  final String? applicantName;
  final String? applicantEmail;
  final Map<String, dynamic>? applicantCV;
  final double? applicationDate;
  final String? jobId;
  final String? userId;
  final Map<String, dynamic>? data;

  JobApplication({
    this.id,
    this.applicantName,
    this.applicantEmail,
    this.applicantCV,
    this.applicationDate,
    this.jobId,
    this.userId,
    this.data,
  });

  // Factory constructor to create a JobApplication object from JSON
  factory JobApplication.fromJson(Map<String, dynamic> json) {
    return JobApplication(
      id: json['_id'],
      applicantName: json['applicantName'],
      applicantEmail: json['applicantEmail'],
      applicantCV: json['applicantCV'] != null
          ? Map<String, dynamic>.from(json['applicantCV'])
          : null,
      applicationDate: json['applicationDate'] != null
          ? double.parse(json['applicationDate'].toString())
          : null,
      jobId: json['jobId'],
      userId: json['userId'],
      data: json['data'] != null
          ? Map<String, dynamic>.from(json['data'])
          : null,
    );
  }

  // Method to convert a JobApplication object to JSON
  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'applicantName': applicantName,
      'applicantEmail': applicantEmail,
      'applicantCV': applicantCV,
      'applicationDate': applicationDate,
      'jobId': jobId,
      'userId': userId,
      'data': data,
    };
  }

  // Method to create a list of JobApplication objects from a list of JSON objects
  static List<JobApplication> fromList(List<dynamic> list) {
    return list.map((item) => JobApplication.fromJson(item)).toList();
  }
}
