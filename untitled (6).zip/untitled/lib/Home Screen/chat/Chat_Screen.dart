import 'package:flutter/material.dart';
import 'package:untitled/animation.dart';
import 'WebSocketService.dart';
import 'package:provider/provider.dart';

class ChatScreen extends StatefulWidget {
  final String userId;
  final String reciverId;

  ChatScreen({required this.userId, required this.reciverId});

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  late SocketService _socketService;
  final TextEditingController _controller = TextEditingController();
  List<Map<String, dynamic>> messages = [];
  bool isHistoryFetched = false;

  @override
  void initState() {
    super.initState();
    _socketService = Provider.of<SocketService>(context, listen: false);
    _socketService.connect(widget.userId);

    _socketService.socket.on('connect', (_) {
      print('Connected to socket server');
      if (!isHistoryFetched) {
        _socketService.getChatHistory();
      }
    });

    _socketService.socket.on('chat-message', (data) {
      if (_isMessageBetweenUsers(data)) {
        if (mounted) {
          setState(() {
            messages.add({
              'content': data['message'] ?? 'Message content is empty',
              'sentBy': data['sentBy'],
              'createdAt': data['createdAt'] ?? DateTime.now().millisecondsSinceEpoch,
            });
            _sortMessagesByTime();
          });
        }
      }
    });

    _socketService.socket.on('chat-history', (data) {
      print('Chat history data: $data');
      if (mounted) {
        setState(() {
          messages.clear();
          for (var item in data) {
            if (_isChatBetweenUsers(item['recepients'])) {
              for (var msg in item['messages']) {
                messages.add({
                  'content': msg['content'] ?? 'No content',
                  'sentBy': msg['sentBy'],
                  'createdAt': msg['createdAt'] ?? DateTime.now().millisecondsSinceEpoch,
                });
              }
            }
          }
          _sortMessagesByTime();
          isHistoryFetched = true;
        });
      }
    });
    Future.delayed(Duration(seconds: 1), () {
      _refreshChatHistory();
    });
  }

  bool _isChatBetweenUsers(List recepients) {
    final userId = widget.userId;
    final receiverId = widget.reciverId;
    return recepients.any((recipient) => recipient['id'] == userId) &&
        recepients.any((recipient) => recipient['id'] == receiverId);
  }

  bool _isMessageBetweenUsers(Map<String, dynamic> data) {
    final sentBy = data['sentBy'];
    final recipientId = data['receiverId'];
    return (sentBy == widget.userId && recipientId == widget.reciverId) ||
        (sentBy == widget.reciverId && recipientId == widget.userId);
  }

  void _sortMessagesByTime() {
    messages.sort((a, b) => (b['createdAt'] as int).compareTo(a['createdAt'] as int));
  }

  Future<void> _sendMessage(String message) async {
    try {
      await _socketService.sendMessage(message, widget.reciverId);
      // Wait for 1 second before refreshing chat history
      Future.delayed(Duration(seconds: 1), () {
        _refreshChatHistory();
      });
    } catch (error) {
      print('Error sending message: $error');
    }
  }

  void _refreshChatHistory() {
    _socketService.getChatHistory(); // Fetch chat history again
  }

  @override
  void dispose() {
    _socketService.disconnect();
    _socketService.socket.off('chat-message');
    _socketService.socket.off('chat-history'); // Ensure the listener is removed
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Chat',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: appConstColor,
        elevation: 5,
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: ListView.builder(
              reverse: true,
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final message = messages[index];
                return MessageWidget(
                  content: message['content'],
                  sentBy: message['sentBy'],
                  currentUserId: widget.userId,
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      hintText: 'Enter your message',
                      filled: true,
                      fillColor: Colors.grey[200],
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30.0),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: EdgeInsets.symmetric(horizontal: 16.0),
                    ),
                  ),
                ),
                SizedBox(width: 8.0),
                FloatingActionButton(
                  onPressed: () async {
                    if (_controller.text.isNotEmpty) {
                      await _sendMessage(_controller.text);
                      _controller.clear();
                    }
                  },
                  child: Icon(Icons.send),
                  backgroundColor: appConstColor,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class MessageWidget extends StatelessWidget {
  final String content;
  final String sentBy;
  final String currentUserId;

  MessageWidget({
    required this.content,
    required this.sentBy,
    required this.currentUserId,
  });

  @override
  Widget build(BuildContext context) {
    final isCurrentUser = sentBy == currentUserId;

    return Align(
      alignment: isCurrentUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 5.0, horizontal: 10.0),
        padding: EdgeInsets.all(10.0),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        decoration: BoxDecoration(
          color: isCurrentUser ? Colors.blueAccent : Colors.grey[300],
          borderRadius: BorderRadius.circular(20.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black26,
              blurRadius: 2.0,
              offset: Offset(1, 1),
            ),
          ],
        ),
        child: Text(
          content,
          style: TextStyle(
            color: isCurrentUser ? Colors.white : Colors.black87,
            fontSize: 16,
          ),
        ),
      ),
    );
  }
}
