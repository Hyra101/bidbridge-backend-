import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:untitled/animation.dart';

import 'Chat_Screen.dart';
import 'WebSocketService.dart';

class ChatListScreen extends StatefulWidget {
  @override
  State<ChatListScreen> createState() => _ChatListScreenState();
}

class _ChatListScreenState extends State<ChatListScreen> {
  late Future<String> userId;
  late SocketService _socketService;

  Future<String> getUserId() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String userId = await prefs.getString("userId") ?? "";
    _socketService = Provider.of<SocketService>(context, listen: false);
    _socketService.connect(userId);
    await Future.delayed(Duration(seconds: 3));
    return userId;
  }

  @override
  void dispose() {
    _socketService.disconnect();
    _socketService.socket.off('chat-message'); // Ensure the listener is removed
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    userId = getUserId();
  }

  @override
  Widget build(BuildContext context) {
    final socketService = Provider.of<SocketService>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Chats',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: appConstColor,
        elevation: 5,
      ),
      body: FutureBuilder(
        future: userId,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.blueAccent),
              ),
            ); // Show a loading indicator while waiting for the tasks
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}')); // Show an error message if there's an issue
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No tasks found.')); // Show a message if no tasks are found
          } else {
            final userData = snapshot.data!;
            return ListView.builder(
              padding: EdgeInsets.all(8.0),
              itemCount: socketService.chatList.length,
              itemBuilder: (context, index) {
                final chatPartner = socketService.chatList[index];
                return Card(
                  elevation: 2,
                  margin: EdgeInsets.symmetric(vertical: 8.0),
                  child: ListTile(
                    contentPadding: EdgeInsets.all(12.0),
                    leading: CircleAvatar(
                      backgroundImage: chatPartner['avatar'] != null
                          ? NetworkImage(chatPartner['avatar']['url'])
                          : null,
                      child: chatPartner['avatar'] == null
                          ? Text(chatPartner['name'][0].toUpperCase())
                          : null,
                    ),
                    title: Text(
                      chatPartner['name'],
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    trailing: Icon(
                      Icons.chat_bubble_outline,
                      color: Colors.blueAccent,
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ChatScreen(
                            userId: userData,
                            reciverId: chatPartner['id'],
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}
