import 'package:socket_io_client/socket_io_client.dart' as IO;

import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:untitled/animation.dart';

class SocketService {
  late IO.Socket socket;
  List<Map<String, dynamic>> chatList = [];

  void connect(String userId) {
    socket = IO.io(appBaseUrl, <String, dynamic>{
      'transports': ['websocket'],
      'autoConnect': false,
      'query': {'userId': userId},
    });

    socket.connect();

    socket.on('connect', (_) {
      print('Connected to socket server');
      getChatHistory(); // Request chat history on connection
    });

    socket.on('chat-history', (data) {
      _parseChatHistory(data, userId); // Parse chat history
    });

    socket.on('disconnect', (_) {
      print('Disconnected from socket server');
    });
  }



  Future<void> sendMessage(String message, String receiverId) async {
    // Your logic to send the message
    // Example:
    socket.emit('chat-message', {
      'message': message,
      'receiverId': receiverId,
    });
    // This is a placeholder for an actual async operation
    return Future.value();
  }

  void _parseChatHistory(dynamic data, String userId) {
    chatList.clear();
    for (var chat in data) {
      for (var recipient in chat['recepients']) {
        if (recipient['id'] != userId) {
          chatList.add({
            'id': recipient['id'],
            'name': recipient['name'],
            'avatar': recipient['avatar'],
          });
        }
      }
    }

    // Remove duplicate recipients from the chat list
    chatList = chatList.toSet().toList();
    print('Parsed chat list: $chatList');
  }



  // Request chat history
  void getChatHistory() {
    socket.emit('chat-history');
  }

  void disconnect() {
    socket.disconnect();
    IO.cache.clear();

  }
}


// class SocketService {
//   late IO.Socket socket;
//
//   void connect(String userId) {
//     // Configure the connection
//     socket = IO.io('http://192.168.100.84:3000', <String, dynamic>{
//       'transports': ['websocket'],
//       'autoConnect': false,
//       'query': {'userId': userId},
//     });
//
//     // Connect to the server
//     socket.connect();
//
//     // Handle connection event
//     socket.on('connect', (_) {
//       print('Connected to socket server');
//       socket.emit('chat-history');  // Request chat history on connection
//     });
//
//     // Listen for incoming chat messages
//     socket.on('chat-message', (data) {
//       print('New chat message: $data');
//       socket.emit('chat-history'); // Request chat history after receiving a new message
//     });
//
//     // Listen for chat history
//     socket.on('chat-history', (data) {
//       print('Chat history: $data');
//       socket.emit('chat-history'); // Request chat history after receiving the initial history
//     });
//
//     // Handle disconnection
//     socket.on('disconnect', (_) {
//       print('Disconnected from socket server');
//     });
//   }
//
//   // Send a chat message
//   void sendMessage(String message, String receiverId) {
//     socket.emit('chat-message', {
//       'message': message,
//       'receiverId': receiverId,
//     });
//   }
//
//   // Request chat history
//   void getChatHistory() {
//     socket.emit('chat-history');
//   }
//
//   // Disconnect from the server
//   void disconnect() {
//     socket.disconnect();
//   }
// }


