import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:untitled/Home%20Screen/task_screen.dart';

import 'bid/Bid_Api_Handler.dart';


class TaskDetailsScreen extends StatefulWidget {
  final Task task;
  bool? showUpdateButton;
  TaskDetailsScreen({super.key, required this.task, this.showUpdateButton});

  @override
  State<TaskDetailsScreen> createState() => _TaskDetailsScreenState();
}

class _TaskDetailsScreenState extends State<TaskDetailsScreen> {

  late List<Bid> tasksFuture; // Define the future to hold the tasks

  final _categories = <String>[
    "Less than 3 months",
    "3 to 6 months",
    "More than 6 months",
  ];

  String? _category;

  TextEditingController salaryController = TextEditingController();

  final BidApiHandler _apiHandler = BidApiHandler();

  bool bidAlreadySent = false;
  // Function to check if any bid has the specified userId
  Future<bool> checkUserIdInBids() async {
    tasksFuture =await _getAllTasks();
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userId =await prefs.getString('userId');
    // Wait for the tasksFuture to complete and get the list of bids


    // Iterate through the list of bids and check if any bid has the matching userId
    for (Bid bid in tasksFuture) {
      if (bid.userId == userId) {
        bidAlreadySent = true;
        setState(() {

        });
        return true; // Return true if a match is found
      }
    }

    return false; // Return false if no match is found
  }

  void _addTask() async {
    if (salaryController.text.isEmpty ||
        _category == null ) {
      _showSnackBar('All fields must be filled');
      return;
    }

    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userId =await prefs.getString('userId');

    Map<String, dynamic> taskData = {
      "bidRate": salaryController.text,
      "deliveryTime": _category,
      "taskId": widget.task.id,
      "userId": userId,
    };

    final response = await _apiHandler.addBid(taskData);
    if (response.statusCode == 200) {
      _showSnackBar('Task added successfully');
      setState(() {
        bidAlreadySent = true;
      });
    } else {
      _showSnackBar('Failed to add task');
    }
  }


  void _updateTask() async {

    if (salaryController.text.isEmpty ||
        _category == null ) {
      _showSnackBar('All fields must be filled');
      return;
    }


    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userId =await prefs.getString('userId');
    Map<String, dynamic> updateData = {
      "bidRate": salaryController.text,
      "deliveryTime": _category,
      "taskId": widget.task.id,
      "userId": userId,
    };


    final response = await _apiHandler.updateBid(widget.task!.id!, updateData);
    if (response.statusCode == 200) {
      _showSnackBar('Task updated successfully');
    } else {
      _showSnackBar('Failed to update task');
    }
  }

  @override
  void initState() {
    super.initState();

    checkUserIdInBids();// Fetch the tasks when the screen is initialized
  }

  Future<List<Bid>> _getAllTasks() async {
    final response = await _apiHandler.getBidsByTaskId(widget.task!.id!); // Adjust this to your actual API handler method
    if (response.statusCode == 200) {
      final responseData = jsonDecode(response.body);
      if (responseData['success']) {
        return Bid.fromList(responseData['bids']); // Extract tasks from 'data' field
      } else {
        _showSnackBar('Failed to retrieve all tasks');
        return [];
      }
    } else {
      _showSnackBar('Failed to retrieve all tasks');
      return [];
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Task Details'),
        backgroundColor: Color(0xff770737),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Task Title
            Text(
              widget.task.title!,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black87),
            ),
            SizedBox(height: 12),
            // Task Description
            Text(
              widget.task.description!,
              style: TextStyle(fontSize: 16, color: Colors.black54),
            ),
            SizedBox(height: 16),
            // Location
            Row(
              children: [
                Icon(Icons.location_on, color: Colors.black54, size: 20),
                SizedBox(width: 8),
                Text(
                  'Location: ${widget.task.location}',
                  style: TextStyle(fontSize: 16, color: Colors.black87),
                ),
              ],
            ),
            SizedBox(height: 12),

            // Budget
            Row(
              children: [
                Icon(Icons.attach_money, color: Colors.black54, size: 20),
                SizedBox(width: 8),
                Text(
                  'Budget: \$${widget.task.budget}',
                  style: TextStyle(fontSize: 16, color: Colors.black87),
                ),
              ],
            ),
            SizedBox(height: 12),

            // Required Skills
            Text(
              'Required Skills:',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black87),
            ),
            SizedBox(height: 8),
            Wrap(
              spacing: 8.0,
              runSpacing: 4.0,
              children: widget.task.requiredSkills!.split(',').map((skill) {
                return Chip(
                  label: Text(skill.trim()),
                  backgroundColor: Colors.blueAccent.shade100,
                  labelStyle: TextStyle(color: Colors.blueAccent.shade700),
                );
              }).toList(),
            ),
            SizedBox(height: 20),

            Text(
              'Estimated Budget',
              style: TextStyle(
                fontSize: 13,
                color: Color(0xFF0C253F),
              ),
            ),
            SizedBox(
              height: 6,
            ),
            TextField(
              controller: salaryController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                  hintText: 'Min-Max',
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(
                      color: Colors.black12,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(
                      color: Colors.black12,
                    ),
                  ),
                  hintStyle:
                  TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
                  isDense: true),
            ),
            Text(
              'Delivery Time',
              style: TextStyle(
                fontSize: 13,
                color: Color(0xFF0C253F),
              ),
            ),
            SizedBox(
              height: 6,
            ),
            DropdownButtonFormField<String>(
              hint: Text('Select delivery time'),
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
              decoration: InputDecoration(
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(
                      color: Colors.black12,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(
                      color: Colors.black12,
                    ),
                  ),
                  hintStyle: const TextStyle(
                    color: Color(0xFF828A89),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                  ),
                  isDense: true),
              value: _category,
              onChanged: (value) {
                setState(() {
                  _category = value;
                });
              },
              items: _categories
                  .map(
                    (e) => DropdownMenuItem(
                  value: e,
                  child: Text(
                    e,
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: Color(0xFF0C253F)),
                  ),
                ),
              )
                  .toList(),
            ),
            SizedBox(
              height: 15,
            ),
            // Bid Now Button
            Align(
              alignment: Alignment.center,
              child: ElevatedButton(
                onPressed: widget.showUpdateButton != null
                    ? _updateTask
                    : bidAlreadySent ? null : _addTask,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xff770737), // Background color
                  padding: EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(6),
                  ),
                ),
                child: Text(
                  widget.showUpdateButton != null ?
                  "Update Data " :
                  bidAlreadySent ?
                  "Bid Already Sent" :
                  'Bid Now',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
