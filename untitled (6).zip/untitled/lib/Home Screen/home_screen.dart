import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:untitled/Home%20Screen/TaskDetailsScreen.dart';
import 'package:untitled/Home%20Screen/recent_tasks/recent_tasks_screen.dart';
import 'package:untitled/Home%20Screen/task_screen.dart';
import 'package:untitled/Home%20Screen/tasks/TaskApiHandler.dart';
import 'package:untitled/Home%20Screen/work/work_screen.dart';
import 'package:untitled/Navigation%20Drawer/drawer_screen.dart';
import 'package:untitled/animation.dart';
import 'package:untitled/category/CategoryPage.dart';
import 'package:untitled/login_screen/RegisterApiHandler.dart';
import 'package:untitled/sliders/Image_Slider.dart';
import 'package:untitled/sliders/Slider_Const.dart';

import '../category/Category.dart';
import '../companies/Company.dart';
import '../login_screen/login_screen.dart';
import '../projects/Project_Details.dart';
import '../projects/const.dart';
import '../projects/projects_api.dart';
import 'employes/employe_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<List<Task>> tasksFuture;
  final TasksApiHandler _apiHandler = TasksApiHandler();


  List<Project> projects = [];

  List<Category> categories = [];

  List<Company> companies = [];
  bool isLoading = true;

  bool canSearch = false;

  TextEditingController searchedController = TextEditingController();

  void getCategories() {
    if (Category.categories.length > 5) {
      categories.add(Category.categories[0]);
      categories.add(Category.categories[1]);
      categories.add(Category.categories[2]);
      categories.add(Category.categories[3]);
      categories.add(Category.categories[4]);
    } else {
      categories = Category.categories;
    }
  }

  void getCompanies() {
    if (Company.companies.length > 5) {
      companies.add(Company.companies[0]);
      companies.add(Company.companies[1]);
      companies.add(Company.companies[2]);
      companies.add(Company.companies[3]);
      companies.add(Company.companies[4]);
    } else {
      companies = Company.companies;
    }
  }

  void toggleSearch() {
    canSearch = !canSearch;
    setState(() {});
  }

  Future<List<Task>> _getAllTasks() async {
    final response = await _apiHandler.getAllTasks(); // Adjust this to your actual API handler method
    if (response.statusCode == 200) {
      final responseData = jsonDecode(response.body);
      if (responseData['success']) {
        List<Task> tasks = Task.fromList(responseData['tasks']);

        // Check if the task list contains more than 4 tasks
        if (tasks.length > 4) {
          // Sort the tasks by createdAt in descending order to get the newest tasks first
          tasks.sort((a, b) => b.createdAt!.compareTo(a.createdAt!));
          // Return only the newest 4 tasks
          return tasks.take(4).toList();
        } else {
          // Return all tasks if there are 4 or fewer
          return tasks;
        }
      } else {
        _showSnackBar('Failed to retrieve all tasks');
        return [];
      }
    } else {
      _showSnackBar('Failed to retrieve all tasks');
      return [];
    }
  }


  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  void initState() {
    super.initState();
    if (UserApiHandler.isFreelancer) {
      tasksFuture = _getAllTasks(); // Fetch the tasks when the screen is initialized
    }
    ProjectConstants.loadProjects(isJob: false).then((value) {
      getCategories();
      getCompanies();
      if (value.length > 2) {
        projects.add(value[0]);
        projects.add(value[1]);
      } else {
        projects = value;
      }
      Future.delayed(Duration(seconds: 2), () {
        setState(() {
          isLoading = false;
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // iconTheme: IconThemeData(color: Colors.red),
        title:Text(
          'Home',
          style: TextStyle(
            // color: Colors.red
          ),
        ),
        actions: [
          PopupMenuButton(
            itemBuilder: (_) {
              return [
                PopupMenuItem(
                  child: TextButton(
                    onPressed: () {},
                    child: Text("Facebook",style: TextStyle(color: appConstColor),),
                  ),
                ),
                PopupMenuItem(
                  child: TextButton(
                    onPressed: () {},
                    child: Text("contact us",style: TextStyle(color: appConstColor),),
                  ),
                ),
                PopupMenuItem(
                    child: TextButton(
                      onPressed: () {},
                      child: Text("Privacy Policy",style: TextStyle(color: appConstColor),
                      ),
                    )),
                PopupMenuItem(
                    child: TextButton(
                        onPressed: () {
                          showDialog(
                            context: context,
                            builder: (_) {
                              return AlertDialog(
                                title: Text("Do you want to logout"),
                                actions: [
                                  TextButton(
                                    onPressed: () {
                                      UserApiHandler.logout();
                                      Navigator.pushReplacement(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  LoginScreen()));
                                    },
                                    child: Text(
                                      "Yes",
                                      style:
                                      TextStyle(color: Color(0xff770737)),
                                    ),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      Navigator.pop(context);
                                    },
                                    child: Text(
                                      "No",
                                      style:
                                      TextStyle(color: Color(0xff770737)),
                                    ),
                                  ),
                                ],
                              );
                            },
                          );
                        },
                        child: Text("Logout")))
              ];
            },
            child: Icon(Icons.more_vert),
          ),
        ],
      ),
      drawer: MyDrawer(),
      body: isLoading
          ? loadingAnimation
          : SingleChildScrollView(
        child: Column(
          children: [
            ImageSlider(imagePaths: upperSliderImages),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Popular Categories',
                    style: TextStyle(
                        fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => CategoryPage(
                                categories: Category.categories)),
                      );
                    },
                    child: Text(
                      'Browse All',
                      style: TextStyle(color: Color(0xff770737)),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
                height: 130,
                child: GestureDetector(
                    child: ScrollCategory(categories: categories))),
            SizedBox(
              height: 12,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if(UserApiHandler.isFreelancer)
                  InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => WorkScreen()));
                    },
                    child: Card(
                      color: Colors.amber,
                      margin: EdgeInsets.all(8.0),
                      elevation: 4.0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0)),
                      child: Container(
                        width: MediaQuery.of(context).size.width * .8,
                        height: 133,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              'Find Work',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                if(!UserApiHandler.isFreelancer)
                  InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => EmployrScreen()));
                    },
                    child: Card(
                      margin: EdgeInsets.all(8.0),
                      color: Colors.amber,
                      elevation: 4.0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0)),
                      child: Container(
                        width: MediaQuery.of(context).size.width * .8,
                        height: 133,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              'For Employes',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                      ),
                    ),
                  )
              ],
            ),
            SizedBox(height: 9),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Recent Tasks',
                    style: TextStyle(
                        fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => RecentTasksScreen()),
                      );
                    },
                    child: Text(
                      'Browse All',
                      style: TextStyle(color: Color(0xff770737)),
                    ),
                  ),
                ],
              ),
            ),
            if(UserApiHandler.isFreelancer)
              SizedBox(
                  height: MediaQuery.of(context).size.height * .3,
                  child: FutureBuilder<List<Task>>(
                      future: UserApiHandler.isFreelancer ? tasksFuture : Future.value([]),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return CircularProgressIndicator();
                        }
                        else if (snapshot.hasData && snapshot.data!.isNotEmpty) {
                          return ListView.builder(
                            itemCount: snapshot.data!.length,
                            physics: BouncingScrollPhysics(),
                            scrollDirection: Axis.horizontal,
                            shrinkWrap: true,
                            padding: EdgeInsets.symmetric(horizontal: 10, vertical: 1),
                            itemBuilder: (context, index) {
                              final task = snapshot.data![index];
                              return Padding(
                                padding: const EdgeInsets.symmetric(vertical: 3),
                                child: Card(
                                  color: Colors.white,
                                  elevation: 2,
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(6)),
                                  child: Container(
                                    margin: EdgeInsets.symmetric(vertical: 7),
                                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 12),
                                    width: 166,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Flexible(
                                          flex: 2,
                                          child: Text(
                                            task.title!,
                                            style:
                                            TextStyle(fontWeight: FontWeight.w500, fontSize: 15),
                                          ),
                                        ),
                                        SizedBox(
                                          height: 4,
                                        ),

                                        Flexible(
                                            flex: 2,
                                            child:
                                            Text(task.description!,overflow: TextOverflow.ellipsis,)),
                                        SizedBox(
                                          height: 6,
                                        ),
                                        Row(
                                          children: [
                                            Icon(
                                              Icons.location_on_outlined,
                                              size: 16,
                                              color: Color(0x99131A22),
                                            ),
                                            SizedBox(
                                              width: 5,
                                            ),
                                            Text('Online')
                                          ],
                                        ),
                                        SizedBox(
                                          height: 6,
                                        ),
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              'Fixed Price',
                                              style: TextStyle(
                                                  color: Colors.green,
                                                  // fontSize: 13
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            Text(
                                              '${task.budget}',
                                              style: TextStyle(
                                                  fontWeight: FontWeight.w500, fontSize: 12),
                                            ),
                                          ],
                                        ),

                                        SizedBox(
                                          height: 13,
                                        ),
                                        InkWell(
                                          onTap: () {
                                            Navigator.push(context,
                                                MaterialPageRoute(builder: (context) => TaskDetailsScreen(task: task)));
                                          },
                                          child: Container(
                                            // width: MediaQuery.of(context).size.width * .5,
                                            padding:
                                            EdgeInsets.symmetric(vertical: 9, horizontal: 6),
                                            decoration: BoxDecoration(
                                                color: Color(0xff770737),
                                                borderRadius: BorderRadius.circular(4)),
                                            child: Center(
                                              child: Text(
                                                'Bid Now',
                                                style: TextStyle(
                                                    color: Colors.white,
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 12),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );

                            },
                          );}
                        else{
                          return Placeholder();
                        }
                      })),
            if(!UserApiHandler.isFreelancer)
              DummyRecentTasks(titles: titles, time: time, fixedPrice: fixedPrice),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Top Rated Freelancers',
                    style: TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold),
                  ),

                ],
              ),
            ),
            SizedBox(
              height: 300, // Adjust height as needed
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: <Widget>[
                    UserProfileCard(
                      profilePicture: 'assets/images/p1.jpeg',
                      name: 'Raquel',
                      expertise: 'Software Engineer',
                      reviews: '4.8/5 (200 reviews)',
                      location: 'Rome,Italy',
                      rate: '\$100/hr',
                    ),
                    UserProfileCard(
                      profilePicture: 'assets/images/p2.jpeg',
                      name: 'Farhan',
                      expertise: 'Data Scientist',
                      reviews: '4.9/5 (150 reviews)',
                      location: 'New York, NY',
                      rate: '\$120/hr',
                    ),
                    UserProfileCard(
                      profilePicture: 'assets/images/p3.jpeg',
                      name: 'Alice',
                      expertise: 'UX Designer',
                      reviews: '4.7/5 (180 reviews)',
                      location: 'Madrid, Spain',
                      rate: '\$90/hr',
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<String> titles = [
    'Food Delivery Mobile Application',
    '2000 words English to German',
    'Wordpress Theme Installation',
    'PHP core website fixes',
  ];

  List<String> time = [
    '2',
    '5',
    '23',
    '33',
  ];
  List<String> fixedPrice = [
    '\$2,500 - \$4,500',
    '\$80 - \$200',
    '\$50 - \$100',
    '\$60 - \$140',
  ];
}

class DummyRecentTasks extends StatelessWidget {
  const DummyRecentTasks({
    super.key,
    required this.titles,
    required this.time,
    required this.fixedPrice,
  });

  final List<String> titles;
  final List<String> time;
  final List<String> fixedPrice;

  @override
  Widget build(BuildContext context) {
    return SizedBox
      (
      height: MediaQuery.of(context).size.height*.32,
      child: ListView.builder(
        itemCount: 4,
        physics: BouncingScrollPhysics(),
        scrollDirection: Axis.horizontal,
        shrinkWrap: true,
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 1),
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Card(
              color: Colors.white,
              elevation: 2,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(6)),
              child: Container(
                margin: EdgeInsets.symmetric(vertical: 7),
                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 12),
                width: 166,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Flexible(
                      flex: 2,
                      child: Text(
                        titles[index],
                        style:
                        TextStyle(fontWeight: FontWeight.w500, fontSize: 15),
                      ),
                    ),
                    SizedBox(
                      height: 14,
                    ),

                    Row(
                      children: [
                        Icon(
                          Icons.access_time,
                          size: 16,
                          color: Color(0x99131A22),
                        ),
                        SizedBox(
                          width: 2,
                        ),
                        Text('${time[index]} min ago')
                      ],
                    ),
                    SizedBox(
                      height: 6,
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.location_on_outlined,
                          size: 16,
                          color: Color(0x99131A22),
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        Text('Online')
                      ],
                    ),
                    SizedBox(
                      height: 6,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Fixed Price',
                          style: TextStyle(
                              color: Colors.green,
                              // fontSize: 13
                              fontWeight: FontWeight.bold),
                        ),
                        Text(
                          '${fixedPrice[index]}',
                          style: TextStyle(
                              fontWeight: FontWeight.w500, fontSize: 12),
                        ),
                      ],
                    ),

                    SizedBox(
                      height: 13,
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) => ProjectDetailsScreen(projectId: '',)));
                      },
                      child: Container(
                        // width: MediaQuery.of(context).size.width * .5,
                        padding:
                        EdgeInsets.symmetric(vertical: 9, horizontal: 6),
                        decoration: BoxDecoration(
                            color: Color(0xff770737),
                            borderRadius: BorderRadius.circular(4)),
                        child: Center(
                          child: Text(
                            'Bid Now',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 12),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class UserProfileCard extends StatelessWidget {
  final String profilePicture;
  final String name;
  final String expertise;
  final String reviews;
  final String location;
  final String rate;

  UserProfileCard({
    required this.profilePicture,
    required this.name,
    required this.expertise,
    required this.reviews,
    required this.location,
    required this.rate,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(8.0),
      elevation: 4.0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
      child: Container(
        width: 200.0,
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            CircleAvatar(
              radius: 30,
              backgroundImage: AssetImage(profilePicture),
            ),
            SizedBox(height: 8.0),
            Text(
              name,
              style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 6.0),
            Text(
              expertise,
              style: TextStyle(fontSize: 14.0, color: Colors.grey[600]),
            ),
            SizedBox(height: 4.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Icon(Icons.star, color: Colors.amber),
                Text(
                  reviews,
                  style: TextStyle(fontSize: 12.0, color: Colors.grey[600]),
                ),
              ],
            ),
            SizedBox(height: 4.0),
            Row(
              children: [
                Expanded(
                  flex: 1,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Location',
                        style: TextStyle(
                            fontSize: 14.0, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 3.0),
                      Text(
                        location,
                        style:
                        TextStyle(fontSize: 12.0, color: Colors.grey[600]),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                    width: 12.0), // Add some space between location and rate
                Expanded(
                  flex: 1,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Rate',
                        style: TextStyle(
                            fontSize: 14.0, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 3.0),
                      Text(
                        rate,
                        style:
                        TextStyle(fontSize: 12.0, color: Colors.grey[600]),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 12.0),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  // Handle view profile button press
                },
                child: Text(
                  'View Profile',
                  style: TextStyle(color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 9.0),
                  backgroundColor:
                  Color(0xff770737), // Change the button color here
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(
                        8.0), // Adjust the border radius as needed
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }


}
