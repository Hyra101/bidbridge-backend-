import 'dart:convert';

import 'package:flutter/material.dart';
import 'TaskDetailsScreen.dart';
import 'tasks/TaskApiHandler.dart';

class TasksScreen extends StatefulWidget {
  const TasksScreen({super.key});

  @override
  State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen> {
  late Future<List<Task>> tasksFuture; // Define the future to hold the tasks
  final TasksApiHandler _apiHandler = TasksApiHandler();

  @override
  void initState() {
    super.initState();
    tasksFuture = _getAllTasks(); // Fetch the tasks when the screen is initialized
  }

  Future<List<Task>> _getAllTasks() async {
    final response = await _apiHandler.getAllTasks(); // Adjust this to your actual API handler method
    if (response.statusCode == 200) {
      final responseData = jsonDecode(response.body);
      if (responseData['success']) {
        return Task.fromList(responseData['tasks']); // Extract tasks from 'data' field
      } else {
        _showSnackBar('Failed to retrieve all tasks');
        return [];
      }
    } else {
      _showSnackBar('Failed to retrieve all tasks');
      return [];
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'Tasks',
          style: TextStyle(fontWeight: FontWeight.w600, fontSize: 19),
        ),
        elevation: 1,
      ),
      body: FutureBuilder<List<Task>>(
        future: tasksFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator()); // Show a loading indicator while waiting for the tasks
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}')); // Show an error message if there's an issue
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No tasks found.')); // Show a message if no tasks are found
          } else {
            final tasks = snapshot.data!;
            return ListView.builder(
              itemCount: tasks.length,
              physics: BouncingScrollPhysics(),
              shrinkWrap: true,
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              itemBuilder: (context, index) {
                final task = tasks[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Card(
                    color: Colors.white,
                    elevation: 3,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    child: Container(
                      margin: EdgeInsets.symmetric(vertical: 10),
                      padding: EdgeInsets.symmetric(horizontal: 15, vertical: 12),
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            task.title!, // Display the task name
                            style: TextStyle(
                                fontWeight: FontWeight.w600, fontSize: 16),
                          ),
                          SizedBox(height: 6),
                          Row(
                            children: [
                              Icon(
                                Icons.access_time,
                                size: 16,
                                color: Colors.grey.shade600,
                              ),
                              SizedBox(width: 5),
                              Text('${DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(task.createdAt!)).inDays} days ago') // Display the number of days since the task was posted
                            ],
                          ),
                          SizedBox(height: 8),
                          Row(
                            children: [
                              Icon(
                                Icons.location_on_outlined,
                                size: 16,
                                color: Colors.grey.shade600,
                              ),
                              SizedBox(width: 5),
                              Text(task.location!), // Display the task location
                            ],
                          ),
                          SizedBox(height: 10),
                          Text(
                            task.description!, // Display the task description
                            style: TextStyle(color: Colors.black87, fontSize: 13),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis, // Limit description to 2 lines
                          ),
                          SizedBox(height: 10),
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 15),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: task.requiredSkills != null
                                  ? task.requiredSkills!.split(',').map((skill) { // Split skills by comma and display them
                                return Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 6, vertical: 4),
                                  margin: EdgeInsets.symmetric(horizontal: 3),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(4),
                                      color: Colors.grey.shade200),
                                  child: Center(
                                    child: Text(
                                      skill.trim(),
                                      style: TextStyle(
                                          color: Colors.blueAccent.shade700),
                                    ),
                                  ),
                                );
                              }).toList()
                                  : [],
                            ),
                          ),
                          SizedBox(height: 10),
                          Align(
                            alignment: Alignment.center,
                            child: InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => TaskDetailsScreen(task: task), // Navigate to TaskDetailsScreen
                                  ),
                                );
                              },
                              child: Container(
                                width: MediaQuery.of(context).size.width * .5,
                                padding: EdgeInsets.symmetric(
                                    vertical: 12, horizontal: 16),
                                decoration: BoxDecoration(
                                    color: Color(0xff770737),
                                    borderRadius: BorderRadius.circular(6)),
                                child: Center(
                                  child: Text(
                                    'Bid Now',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}



class Task {
  final String? id;
  final String? title;
  final String? type;
  final String? category;
  final String? location;
  final String? budget;
  final String? requiredSkills;
  final String? description;
  final Map<String, dynamic>? data;
  final int? createdAt;
  final String? status;
  final String? userId;
   String? acceptedBid;
  final Map<String, dynamic>? review;

  Task({
    this.id,
    this.title,
    this.type,
    this.category,
    this.location,
    this.budget,
    this.requiredSkills,
    this.description,
    this.data,
    this.createdAt,
    this.status,
    this.userId,
    this.acceptedBid,
    this.review,
  });

  // Factory constructor to create a Task object from JSON
  factory Task.fromJson(Map<String, dynamic> json) {
    return Task(
      id: json['_id'],
      title: json['title'],
      type: json['type'],
      category: json['category'],
      location: json['location'],
      budget: json['budget'],
      requiredSkills: json['requiredSkills'],
      description: json['description'],
      data: json['data'] != null ? Map<String, dynamic>.from(json['data']) : null,
      createdAt: json['createdAt'],
      status: json['status'],
      userId: json['userId'],
      acceptedBid: json['acceptedBid'],
      review: json['review'] != null ? Map<String, dynamic>.from(json['review']) : null,
    );
  }

  // Method to convert a Task object to JSON
  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'title': title,
      'type': type,
      'category': category,
      'location': location,
      'budget': budget,
      'requiredSkills': requiredSkills,
      'description': description,
      'data': data,
      'createdAt': createdAt,
      'status': status,
      'userId': userId,
      'acceptedBid': acceptedBid,
      'review': review,
    };
  }

  // Method to create a list of Task objects from a list of JSON objects
  static List<Task> fromList(List<dynamic> list) {
    return list.map((item) => Task.fromJson(item)).toList();
  }
}










// import 'dart:convert';
//
// import 'package:flutter/material.dart';
// import 'package:untitled/Home%20Screen/task_screen.dart';
//
// import 'bid/Bid_Api_Handler.dart';
//
//
// class TaskDetailsScreen extends StatefulWidget {
//   final Task task;
//
//
//
//   TaskDetailsScreen({super.key, required this.task});
//
//   @override
//   State<TaskDetailsScreen> createState() => _TaskDetailsScreenState();
// }
//
// class _TaskDetailsScreenState extends State<TaskDetailsScreen> {
//
//   late Future<Bid?> tasksFuture; // Define the future to hold the tasks
//
//   final _categories = <String>[
//     "Less than 3 months",
//     "3 to 6 months",
//     "More than 6 months",
//   ];
//
//   String? _category;
//
//   TextEditingController salaryController = TextEditingController();
//
//   final BidApiHandler _apiHandler = BidApiHandler();
//
//
//   @override
//   void initState() {
//     super.initState();
//     tasksFuture = _getAllTasks(); // Fetch the tasks when the screen is initialized
//   }
//
//   Future<Bid?> _getAllTasks() async {
//     final response = await _apiHandler.getUserTasks(widget.task!.id!); // Adjust this to your actual API handler method
//     if (response.statusCode == 200) {
//       final responseData = jsonDecode(response.body);
//       if (responseData['success']) {
//         return Bid.fromJson(responseData['tasks']); // Extract tasks from 'data' field
//       } else {
//         _showSnackBar('Failed to retrieve all tasks');
//         return null;
//       }
//     } else {
//       _showSnackBar('Failed to retrieve all tasks');
//       return null;
//     }
//   }
//
//   void _showSnackBar(String message) {
//     ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Task Details'),
//         backgroundColor: Color(0xff770737),
//       ),
//       body: SingleChildScrollView(
//           padding: const EdgeInsets.all(16.0),
//           child: FutureBuilder<Bid?>(
//             future: tasksFuture,
//             builder: (context, snapshot) {
//               if (snapshot.connectionState == ConnectionState.waiting) {
//                 return Center(child: CircularProgressIndicator()); // Show a loading indicator while waiting for the tasks
//               }
//               else if (snapshot.hasError) {
//                 return Center(child: Text('Error: ${snapshot.error}')); // Show an error message if there's an issue
//               }
//               else if (!snapshot.hasData || snapshot.data == null) {
//                 return Center(child: Text('No tasks found.')); // Show a message if no tasks are found
//               }
//               else {
//                 final tasks = snapshot.data!;
//                 return Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     // Task Title
//                     Text(
//                       widget.task.title!,
//                       style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black87),
//                     ),
//                     SizedBox(height: 12),
//                     // Task Description
//                     Text(
//                       widget.task.description!,
//                       style: TextStyle(fontSize: 16, color: Colors.black54),
//                     ),
//                     SizedBox(height: 16),
//                     // Location
//                     Row(
//                       children: [
//                         Icon(Icons.location_on, color: Colors.black54, size: 20),
//                         SizedBox(width: 8),
//                         Text(
//                           'Location: ${widget.task.location}',
//                           style: TextStyle(fontSize: 16, color: Colors.black87),
//                         ),
//                       ],
//                     ),
//                     SizedBox(height: 12),
//
//                     // Budget
//                     Row(
//                       children: [
//                         Icon(Icons.attach_money, color: Colors.black54, size: 20),
//                         SizedBox(width: 8),
//                         Text(
//                           'Budget: \$${widget.task.budget}',
//                           style: TextStyle(fontSize: 16, color: Colors.black87),
//                         ),
//                       ],
//                     ),
//                     SizedBox(height: 12),
//
//                     // Required Skills
//                     Text(
//                       'Required Skills:',
//                       style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black87),
//                     ),
//                     SizedBox(height: 8),
//                     Wrap(
//                       spacing: 8.0,
//                       runSpacing: 4.0,
//                       children: widget.task.requiredSkills!.split(',').map((skill) {
//                         return Chip(
//                           label: Text(skill.trim()),
//                           backgroundColor: Colors.blueAccent.shade100,
//                           labelStyle: TextStyle(color: Colors.blueAccent.shade700),
//                         );
//                       }).toList(),
//                     ),
//                     SizedBox(height: 20),
//
//                     Text(
//                       'Estimated Budget',
//                       style: TextStyle(
//                         fontSize: 13,
//                         color: Color(0xFF0C253F),
//                       ),
//                     ),
//                     SizedBox(
//                       height: 6,
//                     ),
//                     TextField(
//                       controller: salaryController,
//                       keyboardType: TextInputType.number,
//                       decoration: InputDecoration(
//                           hintText: 'Min-Max',
//                           enabledBorder: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(8),
//                             borderSide: const BorderSide(
//                               color: Colors.black12,
//                             ),
//                           ),
//                           focusedBorder: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(8),
//                             borderSide: const BorderSide(
//                               color: Colors.black12,
//                             ),
//                           ),
//                           hintStyle:
//                           TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
//                           isDense: true),
//                     ),
//
//
//                     Text(
//                       'Delivery Time',
//                       style: TextStyle(
//                         fontSize: 13,
//                         color: Color(0xFF0C253F),
//                       ),
//                     ),
//                     SizedBox(
//                       height: 6,
//                     ),
//                     DropdownButtonFormField<String>(
//                       hint: Text('Select delivery time'),
//                       style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
//                       decoration: InputDecoration(
//                           enabledBorder: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(8),
//                             borderSide: const BorderSide(
//                               color: Colors.black12,
//                             ),
//                           ),
//                           focusedBorder: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(8),
//                             borderSide: const BorderSide(
//                               color: Colors.black12,
//                             ),
//                           ),
//                           hintStyle: const TextStyle(
//                             color: Color(0xFF828A89),
//                             fontSize: 14,
//                             fontWeight: FontWeight.w400,
//                           ),
//                           isDense: true),
//                       value: _category,
//                       onChanged: (value) {
//                         setState(() {
//                           _category = value;
//                         });
//                       },
//                       items: _categories
//                           .map(
//                             (e) => DropdownMenuItem(
//                           value: e,
//                           child: Text(
//                             e,
//                             style: TextStyle(
//                                 fontSize: 14,
//                                 fontWeight: FontWeight.w400,
//                                 color: Color(0xFF0C253F)),
//                           ),
//                         ),
//                       )
//                           .toList(),
//                     ),
//
//                     SizedBox(
//                       height: 15,
//                     ),
//
//                     // Bid Now Button
//                     Align(
//                       alignment: Alignment.center,
//                       child: ElevatedButton(
//                         onPressed: () {
//                           // Implement your bid action here
//                         },
//                         style: ElevatedButton.styleFrom(
//                           backgroundColor: Color(0xff770737), // Background color
//                           padding: EdgeInsets.symmetric(vertical: 12, horizontal: 20),
//                           shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.circular(6),
//                           ),
//                         ),
//                         child: Text(
//                           'Bid Now',
//                           style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
//                         ),
//                       ),
//                     ),
//                   ],
//                 );
//               }
//             },
//           )
//
//
//       ),
//     );
//   }
// }
