import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:untitled/Home%20Screen/home_screen.dart';
import 'package:untitled/Home%20Screen/job/BookMark_Jobs.dart';
import 'package:untitled/Home%20Screen/tasks/TaskManagementScreen.dart';
import 'package:untitled/animation.dart';
import 'package:untitled/profile/profile_screen.dart';
import 'package:untitled/projects/BookmarkProjects.dart';
import '../login_screen/RegisterApiHandler.dart';
import 'chat/ChatListScreen.dart';
import 'task_screen.dart';

class Mainpage extends StatefulWidget {
  const Mainpage({super.key});

  @override
  State<Mainpage> createState() => _MainpageState();
}


class _MainpageState extends State<Mainpage> {


  final UserApiHandler _apiService = UserApiHandler();
  Map<String, dynamic>? _userDetails;


  @override
  void initState() {
    super.initState();
    _fetchUserDetails();
  }

  void _fetchUserDetails() async {
    final details = await _apiService.getUserDetails();
    setState(() {
      _userDetails = details;
      if(_userDetails!["user"]['role']=="freelancer"){
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    Widget _buildTabBarView() {
      return TabBarView(
        children: [
          HomeScreen(),
          ChatListScreen(),
          if(UserApiHandler.isFreelancer)
            BookMarkScreen(),
          if(UserApiHandler.isFreelancer)
            TasksScreen(),
          ProfileScreen(),
        ],
      );
    }
    return _userDetails == null ?
    Center(child: CircularProgressIndicator()): DefaultTabController(
      length:UserApiHandler.isFreelancer ? 5 : 3,
      child: Scaffold(
        body: _buildTabBarView(),
        bottomNavigationBar: TabBar(
          tabs: [
            Tab(icon: Icon(Icons.home,color: Color(0xff770737),)),
            Tab(icon: Icon(Icons.message,color: Color(0xff770737),)),
            if(UserApiHandler.isFreelancer)
              Tab(icon: Icon(Icons.bookmark,color: Color(0xff770737),)),
            if(UserApiHandler.isFreelancer)
              Tab(icon: Icon(Icons.work,color: Color(0xff770737),)),
            Tab(icon: Icon(Icons.person_2,color: Color(0xff770737),)),
          ],
          indicatorColor: whiteColor,
        ),
      ),
    );
  }
}
