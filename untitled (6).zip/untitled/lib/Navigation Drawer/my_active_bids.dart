import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:untitled/Home%20Screen/TaskDetailsScreen.dart';

import '../Home Screen/bid/Bid_Api_Handler.dart';
import '../Home Screen/task_screen.dart';
import '../Home Screen/tasks/TaskApiHandler.dart';

class MyActiveBids extends StatefulWidget {
  const MyActiveBids({super.key});

  @override
  State<MyActiveBids> createState() => _MyActiveBidsState();
}

class _MyActiveBidsState extends State<MyActiveBids> {


  List<Task> tasksFuture=[]; // Define the future to hold the tasks
  final TasksApiHandler _apiHandler = TasksApiHandler();

  final BidApiHandler _bidApiHandler = BidApiHandler();
  late Future<List<Bid>> activeBidsFuture; // Define the future to hold the tasks

  Future<List<Task>> _getAllTasks() async {
    final response = await _apiHandler.getAllTasks(); // Adjust this to your actual API handler method
    if (response.statusCode == 200) {
      final responseData = jsonDecode(response.body);
      if (responseData['success']) {
        tasksFuture = await Task.fromList(responseData['tasks']);
        return tasksFuture;// Extract tasks from 'data' field
      } else {
        _showSnackBar('Failed to retrieve all tasks');
        return [];
      }
    } else {
      _showSnackBar('Failed to retrieve all tasks');
      return [];
    }
  }


  String getTaskName(String id) {
    // Iterate through the list of bids and check if any bid has the matching userId
    for (Task bid in tasksFuture) {
      if (bid.id == id) {
        return bid.title!; // Return true if a match is found
      }
    }

    return ""; // Return false if no match is found
  }

  Task? getTask(String id) {
    // Iterate through the list of bids and check if any bid has the matching userId
    for (Task bid in tasksFuture) {
      if (bid.id == id) {
        return bid; // Return true if a match is found
      }
    }

    return null; // Return false if no match is found
  }

  bool isBidFinished(String id) {
    // Iterate through the list of bids and check if any bid has the matching userId
    for (Task bid in tasksFuture) {
      if (bid.id == id) {
        if(bid.status=='finished')
          return true;// Return true if a match is found
      }
    }

    return false; // Return false if no match is found
  }

  Future<List<Bid>> _getAllBids() async {
    final response = await _bidApiHandler.getAllUserBids(); // Adjust this to your actual API handler method
    if (response.statusCode == 200) {
      final responseData = jsonDecode(response.body);
      if (responseData['success']) {
        return Bid.fromList(responseData['bids']); // Extract tasks from 'data' field
      } else {
        _showSnackBar('Failed to retrieve all tasks');
        return [];
      }
    } else {
      _showSnackBar('Failed to retrieve all tasks');
      return [];
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  void _deleteBid(String bidId) async {
    final response = await _bidApiHandler.deleteBid(bidId);
    if (response.statusCode == 200) {
      _showSnackBar('Bid deleted successfully');
      _getAllTasks();
      activeBidsFuture = _getAllBids();

      setState(() {
      });
    } else {
      _showSnackBar('Failed to delete bid');
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _getAllTasks();
    activeBidsFuture = _getAllBids();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Active Bids'),
        elevation: 1,
        centerTitle: true,
      ),
      body: FutureBuilder<List<Bid>>(
        future: activeBidsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator()); // Show a loading indicator while waiting for the tasks
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}')); // Show an error message if there's an issue
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No tasks found.')); // Show a message if no tasks are found
          } else {
            final tasks = snapshot.data!;
            return ListView.builder(
              itemCount: tasks.length,
              physics: BouncingScrollPhysics(),
              shrinkWrap: true,
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              itemBuilder: (context, index) {
                bool isFinshed = isBidFinished(tasks[index]!.taskId!);
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Card(
                    color: Colors.white,
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(6)),
                    child: Container(
                      margin: EdgeInsets.symmetric(vertical: 7),
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            getTaskName(tasks[index]!.taskId!),
                            style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),
                          ),
                          if(isFinshed)
                            Text(
                              "Finished",
                              style: TextStyle(fontWeight: FontWeight.w500,fontSize: 10),
                            ),
                          Container(
                            width: double.infinity,
                            padding:
                            EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                            margin: EdgeInsets.symmetric(vertical: 19),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                color: Colors.grey.shade200),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Fixed Price'),
                                    Text(
                                      '\$${tasks[index].bidRate}',
                                      style: TextStyle(fontWeight: FontWeight.w500,
                                          fontSize: 12),
                                    ),
                                  ],
                                ),
                                Container(
                                  height: 34,
                                  width: 1,
                                  color: Colors.black54,
                                )
                                ,
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Delivery Time'),
                                    Text(
                                      '${tasks[index].deliveryTime}',
                                      style: TextStyle(fontWeight: FontWeight.w500,
                                          fontSize: 12),
                                    ),
                                  ],
                                ),

                              ],
                            ),
                          ),
                          if(!isFinshed)
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    InkWell(
                                      onTap: (){
                                        Navigator.push(context, MaterialPageRoute(builder: (_){
                                          return TaskDetailsScreen(
                                            task: getTask(tasks[index].taskId!)!,
                                            showUpdateButton: true,
                                          );
                                        }));
                                      },
                                      child: Container(
                                          padding: EdgeInsets.all(5),
                                          decoration: BoxDecoration(
                                              color: Color(0xff770737),
                                              borderRadius: BorderRadius.circular(3)),
                                          child: Icon(
                                            Icons.edit,
                                            // color: Color(0x99131A22),
                                            color: Colors.white,
                                          )),
                                    ),
                                    SizedBox(
                                      width: 15,
                                    ),
                                    InkWell(
                                      onTap: (){
                                        _deleteBid(tasks[index].id!);
                                      },
                                      child: Container(
                                          padding: EdgeInsets.all(5),
                                          decoration: BoxDecoration(
                                              color: Colors.red,
                                              borderRadius: BorderRadius.circular(3)),
                                          child: Icon(
                                            Icons.delete,
                                            color: Colors.white,

                                            // color: Color(0x99131A22),
                                          )),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            );
          }
        },
      )
      ,
    );
  }

}
