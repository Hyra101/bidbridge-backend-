import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:untitled/Home%20Screen/employes/post_job_screen.dart';
import 'package:untitled/Home%20Screen/employes/post_task_screen.dart';
import 'package:untitled/Home%20Screen/job/BookMark_Jobs.dart';
import 'package:untitled/Home%20Screen/job/Job_Screen.dart';
import 'package:untitled/Navigation%20Drawer/companies.dart';
import 'package:untitled/Navigation%20Drawer/invite_friends_screen.dart';
import 'package:untitled/Navigation%20Drawer/manage_bidders.dart';
import 'package:untitled/Navigation%20Drawer/manage_candidate_screen.dart';
import 'package:untitled/Navigation%20Drawer/manage_jobs_screen.dart';
import 'package:untitled/Navigation%20Drawer/pricing_plan/Pricing_Plan.dart';
import 'package:untitled/Navigation%20Drawer/setting_screen.dart';
import 'package:untitled/animation.dart';
import 'package:untitled/category/CategoryPage.dart';
import 'package:untitled/login_screen/RegisterApiHandler.dart';
import 'package:untitled/login_screen/login_screen.dart';
import 'package:untitled/profile/profile_screen.dart';
import 'package:untitled/projects/BookmarkProjects.dart';
import '../Home Screen/chat/WebSocketService.dart';
import '../category/Category.dart';
import '../companies/CompanyListScreen.dart';
import '../login_screen/LoginApiHandler.dart';
import '../notifications/Notification Screen.dart';
import 'manage_tasks.dart';
import 'my_active_bids.dart';
import 'myprofile_screen.dart';

class MyDrawer extends StatefulWidget {
  const MyDrawer({Key? key}) : super(key: key);

  @override
  _MyDrawerState createState() => _MyDrawerState();
}

class _MyDrawerState extends State<MyDrawer> {
  bool isLoading = true;
  final UserApiHandler _apiService = UserApiHandler();
  late Map<String, dynamic> userDetails;

  final List<String> imgList = [
    'https://images.unsplash.com/photo-1522205408450-add114ad53fe?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=368f45b0888aeb0b7b08e3a1084d3ede&auto=format&fit=crop&w=1950&q=80',
    'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=94a1e718d89ca60a6337a6008341ca50&auto=format&fit=crop&w=1950&q=80',
    'https://images.unsplash.com/photo-1523205771623-e0faa4d2813d?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=89719a0d55dd05e2deae4120227e6efc&auto=format&fit=crop&w=1953&q=80',
  ];

  @override
  void initState() {
    super.initState();
    _fetchUserDetails();
  }

  void _fetchUserDetails() async {
    final details = await _apiService.getUserDetails();
    setState(() {
      userDetails = details!;
      isLoading = false;
    });
  }

  Widget buildProfileImage() {
    if (isLoading) {
      return loadingAnimation;
    } else {
      // Assuming 'image' is the key for the base64 image
      return CircleAvatar(
        radius: 30,
        backgroundImage: NetworkImage(imgList[0]),
      );
    }
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    userDetails.clear();

  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          SizedBox(
            height: 44,
          ),
          UserAccountsDrawerHeader(
            decoration: BoxDecoration(
              color: appConstColor,
            ),
            currentAccountPicture: buildProfileImage(),
            accountName: isLoading
                ? Text('Loading...')
                : Text(userDetails['user']["name"]),
            accountEmail: isLoading
                ? Text('Loading...')
                : Text(userDetails["user"]['email']),
          ),
          ListTile(
            leading: Icon(Icons.account_circle_outlined, color: Colors.blue),
            title: Text('View Profile'),
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => ProfileScreen()));
            },
          ),
          ListTile(
            leading: Icon(Icons.category_outlined, color: Colors.green),
            title: Text('Categories'),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          CategoryPage(categories: Category.categories)));
            },
          ),
          ListTile(
            leading: Icon(Icons.notifications, color: Colors.orange),
            title: Text('Notifications'),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => NotificationsScreen()));
            },
          ),
          ListTile(
            leading: Icon(Icons.notifications, color: Colors.orange),
            title: Text('Pricing Plan'),
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => PricingScreen()));
            },
          ),
          if (UserApiHandler.isFreelancer)
            ListTile(
              leading: Icon(Icons.business, color: Colors.purple),
              title: Text('Jobs'),
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => JobsScreen()));
              },
            ),
          if (!UserApiHandler.isFreelancer)
            ExpansionTile(
              expandedAlignment: Alignment.bottomLeft,
              leading: Icon(Icons.business, color: Colors.orange),
              title: Text('Jobs'),
              children: [
                TextButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ManageJobsScreen()));
                    },
                    child: Text(
                      'Manage jobs',
                      style: TextStyle(color: Colors.black),
                    )),
                TextButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => PostJobScreen()));
                    },
                    child: Text(
                      'Post a job',
                      style: TextStyle(color: Colors.black),
                    )),
              ],
            ),
          ExpansionTile(
            expandedAlignment: Alignment.centerLeft,
            leading: Icon(Icons.card_giftcard, color: Colors.orange),
            title: Text('Tasks'),
            children: [
              if (!UserApiHandler.isFreelancer)
                TextButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ManageTasksScreen()));
                    },
                    child: Text(
                      'Manage tasks',
                      style: TextStyle(color: Colors.black),
                    )),
              if (!UserApiHandler.isFreelancer)
                TextButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ManageBiddersScreen()));
                    },
                    child: Text(
                      'Manage Bidders',
                      style: TextStyle(color: Colors.black),
                    )),
              if (UserApiHandler.isFreelancer)
                TextButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => MyActiveBids()));
                    },
                    child: Text(
                      'My Active Bids',
                      style: TextStyle(color: Colors.black),
                    )),
              if (!UserApiHandler.isFreelancer)
                TextButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => PostTaskScreen()));
                    },
                    child: Text(
                      'Post a tasks',
                      style: TextStyle(color: Colors.black),
                    )),
            ],
          ),
          if(UserApiHandler.isFreelancer)
            ListTile(
            leading: Icon(Icons.bookmark, color: Colors.red),
            title: Text('Bookmark'),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => BookMarkScreen()));
            },
          ),
          ListTile(
            leading: Icon(Icons.insert_invitation, color: Colors.brown),
            title: Text('Invite friends'),
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => InvitationScreen()));
            },
          ),
          ListTile(
            leading: Icon(Icons.settings, color: Colors.purple),
            title: Text('Settings'),
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => SettingScreen()));
            },
          ),
          ListTile(
            leading: Icon(Icons.logout, color: Colors.grey),
            title: Text('Logout'),
            onTap: () {
              showDialog(
                context: context,
                builder: (_) {
                  return AlertDialog(
                    title: Text(
                      "Do you want to logout",
                      style: TextStyle(color: Color(0xff770737)), // Title color
                    ),
                    actions: [
                      TextButton(
                        onPressed: () async{
                          await UserApiHandler.logout();
                          SocketService _socketService = Provider.of<SocketService>(context, listen: false);
                          _socketService.disconnect();

                          Navigator.pushAndRemoveUntil(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => LoginScreen()),
                              (route)=>route.isCurrent);
                        },
                        child: Text(
                          "Yes",
                          style: TextStyle(color: Color(0xff770737)), // Button text color
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text(
                          "No",
                          style: TextStyle(color: Color(0xff770737)), // Button text color
                        ),
                      ),
                    ],
                    backgroundColor: Colors.white, // Background color of the dialog
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12), // Optional: rounded corners for the dialog
                    ),
                  );

                },
              );
            },
          ),
        ],
      ),
    );
  }
}
