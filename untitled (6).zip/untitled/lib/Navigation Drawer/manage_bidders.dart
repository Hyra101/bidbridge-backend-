import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:untitled/Home%20Screen/bid/TaskBids.dart';
import 'package:untitled/animation.dart';

import '../Home Screen/bid/Bid_Api_Handler.dart';
import '../Home Screen/task_screen.dart';
import '../Home Screen/tasks/TaskApiHandler.dart';

class ManageBiddersScreen extends StatefulWidget {
  const ManageBiddersScreen({super.key});

  @override
  State<ManageBiddersScreen> createState() => _ManageBiddersScreenState();
}

class _ManageBiddersScreenState extends State<ManageBiddersScreen> {

  late Future<List<Task>> tasksFuture; // Define the future to hold the tasks
  final TasksApiHandler _apiHandler = TasksApiHandler();

  final BidApiHandler _bidApiHandler = BidApiHandler();

  Future<List<Task>> _getAllTasks() async {
    final response = await _apiHandler.getUserTasks(); // Adjust this to your actual API handler method
    if (response.statusCode == 200) {
      final responseData = jsonDecode(response.body);
      if (responseData['success']) {
        print(responseData);
        return Task.fromList(responseData['tasks']); // Extract tasks from 'data' field
      } else {
        _showSnackBar('Failed to retrieve all tasks');
        return [];
      }
    } else {
      _showSnackBar('Failed to retrieve all tasks');
      return [];
    }
  }

  Future<List<Bid>> _getTaskBids(String taskId) async {
    final response = await _bidApiHandler.getBidsByTaskId(taskId); // Adjust this to your actual API handler method
    if (response.statusCode == 200) {
      final responseData = jsonDecode(response.body);
      if (responseData['success']) {
        return Bid.fromList(responseData['bids']); // Extract tasks from 'data' field
      } else {
        _showSnackBar('Failed to retrieve all tasks');
        return [];
      }
    } else {
      _showSnackBar('Failed to retrieve all tasks');
      return [];
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
  @override
  void initState() {
    super.initState();
    tasksFuture = _getAllTasks(); // Fetch the tasks when the screen is initialized
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Manage Bidders'),
        elevation: 1,
        centerTitle: true,
      ),
      body: FutureBuilder<List<Task>>(
        future: tasksFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator()); // Show a loading indicator while waiting for the tasks
          }
          else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}')); // Show an error message if there's an issue
          }
          else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No tasks found.')); // Show a message if no tasks are found
          }
          else {
            final tasks = snapshot.data!;
            return RefreshIndicator(
              onRefresh: () async{
                setState(() {

                });
              },
              child: ListView.builder(
                itemCount: tasks.length,
                physics: BouncingScrollPhysics(),
                shrinkWrap: true,
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                itemBuilder: (context, index) {
                  Future<List<Bid>> taskBidsFuture = _getTaskBids(tasks[index]!.id!); // Define the future to hold the tasks
                  return FutureBuilder(
                      future: taskBidsFuture,
                      builder: (context, snapshot){
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return Center(child: CircularProgressIndicator()); // Show a loading indicator while waiting for the tasks
                        }
                        else if (snapshot.hasError) {
                          return Center(child: Text('Error: ${snapshot.error}')); // Show an error message if there's an issue
                        }
                        else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                          return SizedBox(); // Show a message if no tasks are found
                        }
                        else{
                          final bids = snapshot.data!;
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 3),
                            child: Card(
                              color: Colors.white,
                              elevation: 2,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(6)),
                              child: Container(
                                margin: EdgeInsets.symmetric(vertical: 7),
                                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                                width: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      tasks[index].title!,
                                      style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),
                                    ),
                                    SizedBox(
                                      height: 4,
                                    ),
                                    Row(
                                      children: [
                                        Icon(Icons.access_time,
                                          size: 16,
                                          color: Color(0x99131A22),
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text('${DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(tasks[index].createdAt!)).inDays} days ago')
                                      ],
                                    ),
                                    Container(
                                      width: double.infinity,
                                      padding:
                                      EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                                      margin: EdgeInsets.symmetric(vertical: 19),
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(4),
                                          color: Colors.grey.shade200),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text('Bids'),
                                              Text(
                                                bids.length.toString(),
                                                style: TextStyle(fontWeight: FontWeight.w500,fontSize: 12),
                                              ),
                                            ],
                                          ),
                                          Container(
                                            height: 34,
                                            width: 1,
                                            color: Colors.black54,
                                          ),
                                          Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text('Fixed Price'),
                                              Text(
                                                '\$${tasks[index].budget}',
                                                style: TextStyle(fontWeight: FontWeight.w500,
                                                    fontSize: 12),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                    InkWell(
                                      onTap:tasks[index].acceptedBid!=null ? null: (){
                                        Navigator.push(context, MaterialPageRoute(builder: (_){
                                          return TaskBidsScreen(
                                              bidsList: bids,
                                              task: tasks[index]);
                                        }));
                                      },
                                      child: Container(
                                        // width: MediaQuery.of(context).size.width * .32,
                                        padding: EdgeInsets.symmetric(vertical: 6,horizontal: 5),
                                        decoration: BoxDecoration(
                                            color: tasks[index].acceptedBid!=null ? Colors.black26 :appConstColor,
                                            borderRadius: BorderRadius.circular(4)),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Icon(
                                              tasks[index].acceptedBid!=null?null :Icons.people,
                                              color: Colors.white,
                                              size: 19,
                                            ),
                                            SizedBox(
                                              width: 4,
                                            ),
                                            Text(
                                              tasks[index].acceptedBid!=null  ?"Bid Already Accepted" :'Manage Bidders',
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 13),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        }
                      });
                },
              ),
            );
          }
        },
      )

    );
  }

}





