import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:untitled/Home%20Screen/job_application/Job_Candidates_Screen.dart';

import '../Home Screen/employes/post_job_screen.dart';
import '../Home Screen/job/Job_Api_Handler.dart';
import '../Home Screen/job/Job_Screen.dart';
import '../Home Screen/job_application/JobApplicationApiHandler.dart';


class ManageJobsScreen extends StatefulWidget {
  const ManageJobsScreen({super.key});

  @override
  State<ManageJobsScreen> createState() => _ManageTasksScreenState();
}

class _ManageTasksScreenState extends State<ManageJobsScreen> {

  late Future<List<Job>> tasksFuture; // Define the future to hold the tasks
  final JobApiHandler _jobApiHandler = JobApiHandler();
  final JobApplicationApiHandler _jobApplicationApiHandler = JobApplicationApiHandler();
  Future<List<JobApplication>> _getJobApplications(String jobId) async {
    final response = await _jobApplicationApiHandler.getJobApplicationByJobId(jobId); // Adjust this to your actual API handler method
    if (response.statusCode == 200) {
      final responseData = jsonDecode(response.body);
      if (responseData['success']) {
        return JobApplication.fromList(responseData['jobApplications']); // Extract tasks from 'data' field
      } else {
        _showSnackBar('Failed to retrieve all tasks');
        return [];
      }
    } else {
      _showSnackBar('Failed to retrieve all tasks');
      return [];
    }
  }
  @override
  void initState() {
    super.initState();
    tasksFuture = _getAllJobs(); // Fetch the tasks when the screen is initialized
  }

  Future<List<Job>> _getAllJobs() async {
    final response = await _jobApiHandler.getUserTasks(); // Adjust this to your actual API handler method
    if (response.statusCode == 200) {
      final responseData = jsonDecode(response.body);
      if (responseData['success']) {
        print(responseData);
        return Job.fromList(responseData['jobs']); // Extract tasks from 'data' field
      } else {
        _showSnackBar('Failed to retrieve all tasks');
        return [];
      }
    } else {
      _showSnackBar('Failed to retrieve all tasks');
      return [];
    }
  }

  void _deleteJob(String taskId) async {
    final response = await _jobApiHandler.deleteTask(taskId);
    if (response.statusCode == 200) {
      _showSnackBar('Task deleted successfully');
      tasksFuture = _getAllJobs();

      setState(() {
      });
    } else {
      _showSnackBar('Failed to delete task');
    }
  }


  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Manage Jobs'),
          elevation: 1,
          centerTitle: true,
        ),
        body: FutureBuilder<List<Job>>(
          future: tasksFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator()); // Show a loading indicator while waiting for the tasks
            }
            else if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}')); // Show an error message if there's an issue
            } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return Center(child: Text('No tasks found.')); // Show a message if no tasks are found
            } else {
              final tasks = snapshot.data!;
              return ListView.builder(
                itemCount: tasks.length,
                physics: BouncingScrollPhysics(),
                shrinkWrap: true,
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                itemBuilder: (context, index) {
                  Future<List<JobApplication>> jobApplicationsFuture = _getJobApplications(tasks[index]!.id!); // Define the future to hold the tasks
                  return FutureBuilder(
                      future: jobApplicationsFuture,
                      builder: (context, snapshot){
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return Center(child: CircularProgressIndicator()); // Show a loading indicator while waiting for the tasks
                        }
                        else if (snapshot.hasError) {
                          return Center(child: Text('Error: ${snapshot.error}')); // Show an error message if there's an issue
                        }
                        else{
                          final jobs = snapshot.data!;
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 3),
                            child: Card(
                              color: Colors.white,
                              elevation: 2,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(6)),
                              child: Container(
                                margin: EdgeInsets.symmetric(vertical: 7),
                                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                                width: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      tasks[index].title!,
                                      style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),
                                    ),
                                    SizedBox(
                                      height: 4,
                                    ),
                                    Row(
                                      children: [
                                        Icon(Icons.access_time,
                                          size: 16,
                                          color: Color(0x99131A22),
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text('${DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(int.parse(tasks[index].createdAt!.toStringAsFixed(0)))).inDays} days ago')
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        InkWell(
                                          onTap: (){
                                            Navigator.push(context, MaterialPageRoute(builder: (_){
                                              return JobCandidatesScreen(
                                                  jobApplicationsList: jobs, job: tasks[index]);
                                            }));
                                          },
                                          child: Container(// width: MediaQuery.of(context).size.width * .32,
                                            padding: EdgeInsets.symmetric(vertical: 6,horizontal: 5),
                                            decoration: BoxDecoration(
                                                color: Color(0xff770737),
                                                borderRadius: BorderRadius.circular(4)),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                Icon(
                                                  Icons.people,
                                                  color: Colors.white,
                                                  size: 19,
                                                ),
                                                SizedBox(
                                                  width: 4,
                                                ),
                                                Text(
                                                  'Manage Candidates ${jobs.length}',
                                                  style: TextStyle(
                                                      color: Colors.white,
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 13),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Row(
                                          children: [
                                            Container(
                                                padding: EdgeInsets.all(5),
                                                decoration: BoxDecoration(
                                                    color: Colors.grey.shade200,
                                                    borderRadius: BorderRadius.circular(3)),
                                                child: IconButton(
                                                  icon: Icon(Icons.edit),
                                                  color: Color(0x99131A22),
                                                  onPressed: () {
                                                    Navigator.push(context,
                                                        MaterialPageRoute(builder: (context) => PostJobScreen(
                                                          showUpdate: true,
                                                          task: tasks[index],
                                                        )));
                                                  },

                                                )),

                                            SizedBox(
                                              width: 15,
                                            ),
                                            Container(
                                                padding: EdgeInsets.all(5),
                                                decoration: BoxDecoration(
                                                    color: Colors.grey.shade200,
                                                    borderRadius: BorderRadius.circular(3)),
                                                child: IconButton(
                                                  icon: Icon(Icons.delete),
                                                  color: Color(0x99131A22),
                                                  onPressed: (){
                                                    _deleteJob(tasks[index].id!);
                                                  },
                                                )),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        }
                      });
                },
              );
            }
          },
        )
    );
  }

}


