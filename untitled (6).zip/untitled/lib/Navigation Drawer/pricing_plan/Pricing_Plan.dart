import 'package:flutter/material.dart';
import 'package:untitled/Navigation%20Drawer/pricing_plan/Payment_Screen.dart';

class PricingScreen extends StatefulWidget {
  @override
  _PricingScreenState createState() => _PricingScreenState();
}

class _PricingScreenState extends State<PricingScreen> {
  int selectedPlanIndex = 1; // Default to the 'Standard Plan'
  int selectedBillingIndex = 0; // 0 for 'Billed Monthly', 1 for 'Billed Yearly'

  // Define the color variable
  final Color appConstColor = Color(0xff770737);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pricing Plans'),
        backgroundColor: appConstColor, // Set AppBar color
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ToggleButtons(
              isSelected: [selectedBillingIndex == 0, selectedBillingIndex == 1],
              selectedColor: Colors.white,
              fillColor: appConstColor, // Set fill color for ToggleButtons
              borderRadius: BorderRadius.circular(8),
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Text('Billed Monthly'),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Text('Billed Yearly'),
                ),
              ],
              onPressed: (int index) {
                setState(() {
                  selectedBillingIndex = index;
                });
              },
            ),
            SizedBox(height: 24),
            Expanded(
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _buildPlanCard(
                      title: 'Basic Plan',
                      price: '\$19',
                      description:
                      'One time fee for one listing or task highlighted in search results.',
                      features: ['1 Listing', '30 Days Visibility', 'Highlighted in Search Results'],
                      recommended: false,
                      index: 0,
                      isSelected: selectedPlanIndex == 0,
                      onSelect: () {
                        setState(() {
                          selectedPlanIndex = 0;
                        });
                      },
                    ),
                    _buildPlanCard(
                      title: 'Standard Plan',
                      price: '\$49',
                      description:
                      'One time fee for one listing or task highlighted in search results.',
                      features: ['5 Listings', '60 Days Visibility', 'Highlighted in Search Results'],
                      recommended: true,
                      index: 1,
                      isSelected: selectedPlanIndex == 1,
                      onSelect: () {
                        setState(() {
                          selectedPlanIndex = 1;
                        });
                      },
                    ),
                    _buildPlanCard(
                      title: 'Extended Plan',
                      price: '\$99',
                      description:
                      'One time fee for one listing or task highlighted in search results.',
                      features: ['Unlimited Listings', '90 Days Visibility', 'Highlighted in Search Results'],
                      recommended: false,
                      index: 2,
                      isSelected: selectedPlanIndex == 2,
                      onSelect: () {
                        setState(() {
                          selectedPlanIndex = 2;
                        });
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPlanCard({
    required String title,
    required String price,
    required String description,
    required List<String> features,
    required bool recommended,
    required int index,
    required bool isSelected,
    required VoidCallback onSelect,
  }) {
    return GestureDetector(
      onTap: onSelect,
      child: Container(
        width: 300, // Adjust the width to make it look better
        margin: EdgeInsets.all(8.0),
        padding: EdgeInsets.all(16.0),
        decoration: BoxDecoration(
          color: isSelected ? appConstColor.withOpacity(0.1) : Colors.white,
          borderRadius: BorderRadius.circular(8.0),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 2,
              blurRadius: 7,
              offset: Offset(0, 3),
            ),
          ],
          border: recommended
              ? Border.all(color: appConstColor, width: 2)
              : isSelected
              ? Border.all(color: appConstColor, width: 2)
              : null,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (recommended)
              Text(
                'Recommended',
                style: TextStyle(
                  color: appConstColor,
                  fontWeight: FontWeight.bold,
                ),
              ),
            Text(
              title,
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8.0),
            Text(price, style: TextStyle(fontSize: 24.0)),
            SizedBox(height: 8.0),
            Text(
              description,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12.0, color: Colors.grey),
            ),
            SizedBox(height: 16.0),
            ...features.map((feature) => Padding(
              padding: const EdgeInsets.only(bottom: 4.0),
              child: Text(feature, textAlign: TextAlign.center),
            )),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (_){
                  return PaymentScreen();
                }));
              },
              child: Text('Buy Now'),
              style: ElevatedButton.styleFrom(
                backgroundColor: isSelected ? appConstColor : Colors.grey,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
