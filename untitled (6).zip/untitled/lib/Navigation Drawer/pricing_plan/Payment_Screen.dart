import 'package:flutter/material.dart';
import 'package:untitled/Navigation%20Drawer/pricing_plan/Thank_You_screen.dart';

class PaymentScreen extends StatefulWidget {
  @override
  _PaymentScreenState createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  bool isMonthly = true;
  bool isTermsAccepted = false;

  // Define the color variable
  final Color appConstColor = Color(0xff770737);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Payment'),
        backgroundColor: appConstColor, // Set AppBar color
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Billing Cycle',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: appConstColor),
            ),
            SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: RadioListTile(
                    title: Text("\$49.00 / month"),
                    value: true,
                    groupValue: isMonthly,
                    onChanged: (value) {
                      setState(() {
                        isMonthly = true;
                      });
                    },
                    activeColor: appConstColor, // Set color for selected radio
                  ),
                ),
                Expanded(
                  child: RadioListTile(
                    title: Text("\$529.20 / year"),
                    value: false,
                    groupValue: isMonthly,
                    onChanged: (value) {
                      setState(() {
                        isMonthly = false;
                      });
                    },
                    activeColor: appConstColor, // Set color for selected radio
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            Text(
              'Payment Method',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: appConstColor),
            ),
            SizedBox(height: 10),
            RadioListTile(
              title: Row(
                children: [
                  Text('PayPal'),
                  Spacer(),
                  Image.network(
                    'https://www.paypalobjects.com/webstatic/icon/pp258.png',
                    width: 50,
                  ),
                ],
              ),
              value: 'paypal',
              groupValue: 'paypal',
              onChanged: (value) {},
              activeColor: appConstColor, // Set color for selected radio
            ),
            Spacer(),
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SummarySection(isMonthly: isMonthly, appConstColor: appConstColor),
                SizedBox(height: 10),
                Row(
                  children: [
                    Checkbox(
                      value: isTermsAccepted,
                      onChanged: (value) {
                        setState(() {
                          isTermsAccepted = value ?? false;
                        });
                      },
                      activeColor: appConstColor, // Set color for Checkbox
                    ),
                    Expanded(
                      child: Text(
                        'I agree to the Terms and Conditions and the Automatic Renewal Terms',
                        style: TextStyle(fontSize: 14),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10),
                ElevatedButton(
                  onPressed: isTermsAccepted
                      ? () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) {
                      return ThankYouScreen();
                    }));
                  }
                      : null,
                  child: Text('Proceed Payment'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: appConstColor, // Set button color
                    foregroundColor: Colors.white, // Set text color
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class SummarySection extends StatelessWidget {
  final bool isMonthly;
  final Color appConstColor; // Added color parameter

  SummarySection({required this.isMonthly, required this.appConstColor});

  @override
  Widget build(BuildContext context) {
    double basicPlan = isMonthly ? 19 : 228;
    double vat = basicPlan * 0.2;
    double finalPrice = basicPlan + vat;

    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: appConstColor), // Set border color
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Summary',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: appConstColor),
          ),
          SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Basic Plan'),
              Text('\$${basicPlan.toStringAsFixed(2)} / ${isMonthly ? "monthly" : "yearly"}'),
            ],
          ),
          SizedBox(height: 5),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('VAT (20%)'),
              Text('\$${vat.toStringAsFixed(2)}'),
            ],
          ),
          Divider(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Final Price', style: TextStyle(fontWeight: FontWeight.bold, color: appConstColor)),
              Text(
                '\$${finalPrice.toStringAsFixed(2)} / ${isMonthly ? "monthly" : "yearly"}',
                style: TextStyle(fontWeight: FontWeight.bold, color: appConstColor),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
