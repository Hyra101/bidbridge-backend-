import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:untitled/login_screen/RegisterApiHandler.dart';
import 'package:untitled/widgets/primary_textfield.dart';

import '../Home Screen/MainPage.dart';

class SettingScreen extends StatefulWidget {
  const SettingScreen({super.key});

  @override
  State<SettingScreen> createState() => _SettingScreenState();
}

class _SettingScreenState extends State<SettingScreen> {
  TextEditingController nameController = TextEditingController();
  TextEditingController gmailController = TextEditingController();
  TextEditingController currentPasswordController = TextEditingController();
  UserApiHandler userApiHandler = UserApiHandler();
  double rate = 0;
  final ImagePicker _picker = ImagePicker();
  XFile? profileImage;


  Future<void> _updateAvatar() async {
    if (profileImage != null) {
      bool success = await userApiHandler.updateUserAvatar(profileImage!.path);
      if (success) {
        // Handle successful update, e.g., show a success message or update the UI
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Avatar updated successfully!')),
        );
      } else {
        // Handle failed update
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to update avatar.')),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('No image selected.')),
      );
    }
  }

  Future<void> _validateAndSave() async {
    // Fetch the current user data to get the current password
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? currentPassword = prefs.getString('currentPassword'); // Adjust key as needed

    // Get the entered password from the text controller
    String enteredPassword = currentPasswordController.text;

    // Validate password
    if (enteredPassword == currentPassword) {
      // Check if a role is selected
      if (selectedUser == null || selectedUser!.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Please select a role.')),
        );
        return;
      }

      // Convert the selected role to lowercase
      String role = selectedUser!.toLowerCase();

      // Proceed with updating user details
      bool success = await userApiHandler.updateData(
          role,
          nameController.text,
      );

      if (success) {
        if(selectedUser=="Freelancer"){
          UserApiHandler.isFreelancer=true;
        }
        else{
          UserApiHandler.isFreelancer=false;
        }
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Details updated successfully!')),
        );

        Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
                builder: (context) => Mainpage()),
                (route)=>route.isFirst);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to update details.')),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Current password is incorrect.')),
      );
    }

  }



  Future<void> pickImage() async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() {
        profileImage = image;
      });
      _updateAvatar();
    }
  }

  String? selectedUser;

  final List<String> users = [
    "Freelancer",
    "Employer",
  ];
  Future<void> _saveSliderValues() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setDouble('rate', rate);
  }

    Future<void> _loadSliderValues() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {

      rate = prefs.getDouble('rate') ?? 0.0;
    });
  }

  @override
  void initState() {
_loadSliderValues();    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings'),
        centerTitle: true,
        elevation: 1,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 6,
              ),
              Center(
                child: Stack(
                  clipBehavior: Clip.none,
                  // alignment: Alignment.bottomRight,
                  children: [
                    Container(
                        margin: EdgeInsets.symmetric(vertical: 16),
                        height: MediaQuery.of(context).size.height * .2,
                        width: MediaQuery.of(context).size.width * .42,
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.black12),
                            color: Colors.grey.shade200,
                            borderRadius: BorderRadius.circular(6)),
                        child: profileImage == null
                            ? Icon(
                                Icons.person,
                                size: 66,
                              )
                            : ClipRRect(
                                borderRadius: BorderRadius.circular(6),
                                child: Image.file(
                                  File(profileImage!.path),
                                  fit: BoxFit.cover,
                                ))),
                    Positioned(
                        right: -9,
                        bottom: 12,
                        child: InkWell(
                          onTap: () {
                            pickImage();
                          },
                          child: CircleAvatar(
                            radius: 15,
                            child: Icon(
                              Icons.edit,
                              color: Colors.blue,
                            ),
                          ),
                        ))
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Name',
                    style: TextStyle(
                      fontSize: 13,
                      color: Color(0xFF0C253F),
                    ),
                  ),
                  SizedBox(
                    height: 6,
                  ),
                  PrimaryTextField(
                    controller: nameController,
                    text: 'Name',
                    prefixIcon: Icon(
                      Icons.person,
                      size: 26,
                      color: Color(0xff770737),
                    ),
                  ),
                  SizedBox(
                    height: 14,
                  ),
                  Text(
                    'Email',
                    style: TextStyle(
                      fontSize: 13,
                      color: Color(0xFF0C253F),
                    ),
                  ),
                  SizedBox(
                    height: 6,
                  ),
                  PrimaryTextField(

                    controller: gmailController,
                    text: 'Email',
                    prefixIcon: Icon(
                      Icons.email,
                      size: 26,
                      color: Color(0xff770737),
                    ),
                  ),

                  SizedBox(
                    height: 14,
                  ),
                  Text(
                    'Current Password',
                    style: TextStyle(
                      fontSize: 13,
                      color: Color(0xFF0C253F),
                    ),
                  ),
                  SizedBox(
                    height: 6,
                  ),
                  PrimaryTextField(
                    controller: currentPasswordController,
                    text: 'Current Password',
                    prefixIcon: Icon(
                      Icons.lock,
                      size: 26,
                      color: Color(0xff770737),
                    ),
                  ),
                ],
              ),
          
             SizedBox(
                      height: 14,
                    ),
                    Text(
                      'Account Type',
                      style: TextStyle(
                        fontSize: 13,
                        color: Color(0xFF0C253F),
                      ),
                    ),
                    SizedBox(
                      height: 6,
                    ),
              SizedBox(
                height: 40,
                child: ListView.builder(
                  itemCount: users.length,
                  shrinkWrap: true,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          selectedUser = users[index];
                        });
                      },
                      child: Container(
                        margin: EdgeInsets.symmetric(horizontal: 14),
                        // height: 34,
                        width: MediaQuery.of(context).size.width * .4,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4),
                            color: selectedUser == users[index]
                                ? Colors.green
                                : Colors.grey.shade300),
                        child: Center(
                          child: Text(
                            users[index],
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                color: selectedUser == users[index]
                                    ? Colors.white
                                    : null),
                          ),
                        ),
                      ),
                    );
          
                  
                  },
                ),
              ),
              SizedBox(
                      height: 60,
                    ),

              SizedBox(
                height: 52,
                width: MediaQuery.of(context).size.width,
                child: ElevatedButton(
                  onPressed: _validateAndSave, // Call the new function
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xff770737),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(6.0),
                    ),
                  ),
                  child: const Text(
                    'Save',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                ),
              ),

              const SizedBox(height: 14),
        
            ],
          ),
        ),
      ),
    );
  }
}
