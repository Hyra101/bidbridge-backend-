import 'package:flutter/material.dart';
import 'package:untitled/login_screen/LoginApiHandler.dart';
import 'package:untitled/login_screen/RegisterApiHandler.dart';
import 'package:untitled/login_screen/new_password.dart';

import '../widgets/primary_textfield.dart';

class ForgetPassword extends StatefulWidget {
  const ForgetPassword({Key? key});

  @override
  State<ForgetPassword> createState() => _ForgetPasswordState();
}

class _ForgetPasswordState extends State<ForgetPassword> {
  TextEditingController gmailController = TextEditingController();

  void checkUser()async {
    if (gmailController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text("Please enter email")));
    }
    else {
      UserApiHandler userApiHandler = UserApiHandler();
      var response = await userApiHandler.generateTokenByEmail(gmailController.text);
      if(response!=null){
        Navigator.push(context, MaterialPageRoute(builder: (_){
          return NewPassword(token: response);
        }));

      }else{
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text("User not found")));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          'Forgot Password ',
          style: TextStyle(
            color: Color(0xFF1A1A1A),
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: 38,
              ),
              const Text(
                'Reset your password',
                style: TextStyle(
                  color: Color(0xff770737),
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              const Padding(
                padding: EdgeInsets.only(right: 16, left: 16),
                child: Text(
                  "Don't worry if you forgot your Password,   have a solution for you, Just enter your assosiated email here to get a password reset link",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFF828A89),
                    // fontSize: 16,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
              const SizedBox(
                height: 33,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Email',
                    style: TextStyle(
                      color: Color(0xFF3D3D3D),
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  PrimaryTextField(
              prefixIcon: const Icon(
                Icons.email,
                size: 26,
                color: Color(0xff770737),
              ),
              controller: gmailController,
              text: 'Email address',
            ),
                  const SizedBox(
                    height: 40,
                  ),
                  Center(
                    child: Stack(
                      children: [
                        InkWell(
                          onTap: () async{
                            checkUser();
                          },
                          child: Container(
                            height: 50,
                            width: 349 * 12,
                            decoration: BoxDecoration(
                              color: Color(0xff770737),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Center(
                              child: Text(
                                'Reset',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
