import 'dart:convert';
import 'dart:isolate';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:untitled/Home%20Screen/MainPage.dart';
import 'package:untitled/animation.dart';
import 'package:untitled/main.dart';

import '../Home Screen/chat/WebSocketService.dart';
import '../googlsignin/GoogleSignIn.dart';

class UserApiHandler {
  static const String baseUrl = '$appBaseUrl/users'; // Replace with your server URL

  static bool isFreelancer = false;

  Future<bool> registerUser(String name, String email, String password, String role,context) async {
    final response = await http.post(
      Uri.parse('$baseUrl/register'),
      headers: <String, String>{
        'Content-Type': 'application/json',
      },
      body: jsonEncode(<String, String>{
        'name': name,
        'email': email,
        'password': password,
        'role': role,
      }),
    );

    if (response.statusCode == 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('User Registered Successfully')),
      );
      return true;
    }
    else if(response.body.contains("User already exists")) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("User already exists")),
      );
      return false;
    }
    else{
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to register user")),
      );
      print('Failed to register user');
      return false;
    }
  }

  Future<bool> loginUser(String email, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/login'),
      headers: <String, String>{
        'Content-Type': 'application/json',
      },
      body: jsonEncode(<String, String>{
        'email': email,
        'password': password,
      }),
    );

    if (response.statusCode == 200) {

      final Map<String, dynamic> data = jsonDecode(response.body);
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String role = data['userRole'];
      if(role.trim()=="freelancer"){
        isFreelancer = true;
      }
      await prefs.setString('token', data['token']);
      await prefs.setString('userId', data['id']);

      return true;
    } else {
      print('Failed to login: ${response.body}');
      return false;
    }
  }

  Future<Map<String, dynamic>?> getUserDetails() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    String? token = prefs.getString('token');
    if (token == null) {
      return null;
    }


    final response = await http.get(
      Uri.parse('$baseUrl/details'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'x-access-token': token,
      },
    );

    if (response.statusCode == 200) {
      final userData = jsonDecode(response.body);
      await prefs.setString('userId', userData['user']['_id']);
      await prefs.setString('currentPassword', userData['user']['password']);
      return userData;
    } else {
      print('Failed to get user details: ${response.body}');
      return null;
    }
  }

  Future<Map<String, dynamic>?> getUserDetailsById(String userId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/details/$userId'),
      headers: {'Content-Type': 'application/json'},
    );
    if (response.statusCode == 200) {
      final userData = jsonDecode(response.body);
      return userData;
    } else {
      print('Failed to get user details: ${response.body}');
      return null;
    }
  }

  Future<bool> updateData(String role, String name) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');
    if (token == null) {
      return false;
    }

    final response = await http.post(
      Uri.parse('$baseUrl/update'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'x-access-token': token,
      },
      body: jsonEncode(<String, dynamic>{
        'role': role,
        'name': name,
      }),
    );

    if (response.statusCode == 200) {
      final jsonResponse = jsonDecode(response.body);
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String role = jsonResponse['updatedToken'];
      await prefs.setString('token', role);
      return true;
    } else {
      print('Failed to update user details: ${response.body}');
      return false;
    }
  }

  Future<bool> updateUser(String role, String name, String email, Map<String, dynamic> data) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');
    if (token == null) {
      return false;
    }

    final response = await http.post(
      Uri.parse('$baseUrl/update'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'x-access-token': token,
      },
      body: jsonEncode(<String, dynamic>{
        'role': role,
        'name': name,
        'email': email,
        'data': data,
      }),
    );

    if (response.statusCode == 200) {
      return true;
    } else {
      print('Failed to update user details: ${response.body}');
      return false;
    }
  }

  Future<bool> updateUserAvatar(String filePath) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');
    if (token == null) {
      return false;
    }

    var request = http.MultipartRequest('POST', Uri.parse('$baseUrl/update/avatar'));
    request.headers['x-access-token'] = token;
    request.files.add(await http.MultipartFile.fromPath('avatar', filePath));

    var response = await request.send();

    if (response.statusCode == 200) {
      return true;
    } else {
      print('Failed to update user avatar');
      return false;
    }
  }

  Future<bool> updateUserResume(String filePath) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');
    if (token == null) {
      return false;
    }

    var request = http.MultipartRequest('POST', Uri.parse('$baseUrl/update/resume'));
    request.headers['x-access-token'] = token;
    request.files.add(await http.MultipartFile.fromPath('resume', filePath));

    var response = await request.send();

    if (response.statusCode == 200) {
      return true;
    } else {
      print('Failed to update user resume');
      return false;
    }
  }

  Future<bool> updateUserCoverLetter(String filePath) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');
    if (token == null) {
      return false;
    }

    var request = http.MultipartRequest('POST', Uri.parse('$baseUrl/update/cover'));
    request.headers['x-access-token'] = token;
    request.files.add(await http.MultipartFile.fromPath('cover', filePath));

    var response = await request.send();

    if (response.statusCode == 200) {
      return true;
    } else {
      print('Failed to update user cover letter');
      return false;
    }
  }

  Future<bool> updateNotificationStatus(bool status) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');
    if (token == null) {
      return false;
    }

    final response = await http.post(
      Uri.parse('$baseUrl/update/notifications/status'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'x-access-token': token,
      },
      body: jsonEncode(<String, dynamic>{
        'status': status,
      }),
    );

    if (response.statusCode == 200) {
      return true;
    } else {
      print('Failed to update notification status: ${response.body}');
      return false;
    }
  }

  Future<bool> removeResume() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');
    if (token == null) {
      return false;
    }

    final response = await http.delete(
      Uri.parse('$baseUrl/remove/resume'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'x-access-token': token,
      },
    );

    if (response.statusCode == 200) {
      return true;
    } else {
      print('Failed to remove resume: ${response.body}');
      return false;
    }
  }

  Future<bool> removeCoverLetter() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');
    if (token == null) {
      return false;
    }

    final response = await http.delete(
      Uri.parse('$baseUrl/remove/cover'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'x-access-token': token,
      },
    );

    if (response.statusCode == 200) {
      return true;
    }
    else {
      print('Failed to remove cover letter: ${response.body}');
      return false;
    }
  }

  Future<bool> addBookMark(Map<String, dynamic> data) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');
    if (token == null) {
      return false;
    }

    final response = await http.post(
      Uri.parse('$baseUrl/update'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'x-access-token': token,
      },
      body: jsonEncode(<String, dynamic>{
        'data': data,
      }),
    );

    if (response.statusCode == 200) {
      return true;
    } else {
      print('Failed to update user details: ${response.body}');
      return false;
    }
  }

  Future<String?> generateTokenByEmail(String email) async {
    final response = await http.post(
      Uri.parse('$baseUrl/generate-token'),
      headers: <String, String>{
        'Content-Type': 'application/json',
      },
      body: jsonEncode(<String, dynamic>{
        'email': email,
      }),
    );

    if (response.statusCode == 200) {
      final jsonResponse = jsonDecode(response.body);
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String role = jsonResponse['userRole'];
      if(role.trim()=="freelancer"){
        isFreelancer = true;
      }
      await prefs.setString('token', jsonResponse['token']);
      await prefs.setString('userId', jsonResponse['id']);


      return await jsonResponse['token'];
    } else {
      print('Failed to generate token by email: ${response.body}');
      return null;
    }
  }

  Future<bool> changePassword(String newPassword, String? token) async {
    if (token == null) {
      return false;
    }

    final response = await http.post(
      Uri.parse('$baseUrl/change-password'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'x-access-token': token,
      },
      body: jsonEncode(<String, dynamic>{
        'newPassword': newPassword,
      }),
    );

    if (response.statusCode == 200) {
      return true;
    } else {
      print('Failed to change password: ${response.body}');
      return false;
    }
  }

  static logout() async {
    try {

      await GoogleSignInApi.logout();
    } catch (e) {}
    try {
    } catch (e) {}
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove("userId");
    await prefs.remove("token");

    await prefs.clear();

    isFreelancer = false;



  }

}

//
//
// // Method to handle Google authentication
// Future<void> authenticateWithGoogle() async {
//   final String url = "$_baseUrl/auth/google";
//   try {
//     final response = await http.get(Uri.parse(url), headers: {
//       'Accept': 'application/json',
//     });
//
//     if (response.statusCode == 302) {
//       // Handle redirection to Google OAuth
//       String redirectUrl = response.headers['location']!;
//       // You can then open this URL in a web view or browser
//       print("Redirect to Google OAuth: $redirectUrl");
//     } else {
//       print("Failed to authenticate with Google: ${response.body}");
//     }
//   } catch (e) {
//     print("Error during Google authentication: $e");
//   }
// }
//
// // Method to handle Google authentication callback
// Future<void> handleGoogleCallback(String code) async {
//   final String url = "$_baseUrl/auth/google/callback?code=$code";
//   try {
//     final response = await http.get(Uri.parse(url), headers: {
//       'Accept': 'application/json',
//     });
//
//     if (response.statusCode == 200) {
//       // Successfully authenticated, handle the response
//       final responseData = json.decode(response.body);
//       print("Google Authentication Successful: $responseData");
//     } else {
//       print("Failed to authenticate with Google: ${response.body}");
//     }
//   } catch (e) {
//     print("Error during Google callback handling: $e");
//   }
// }