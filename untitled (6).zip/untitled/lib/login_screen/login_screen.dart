import 'package:flutter/material.dart';
import 'package:untitled/googlsignin/GoogleSignIn.dart';
import 'package:untitled/login_screen/RegisterApiHandler.dart';
import 'package:untitled/login_screen/new_password.dart';
import 'package:untitled/login_screen/signup.dart';
import 'package:untitled/widgets/primary_textfield.dart';

import '../Home Screen/MainPage.dart';
import '../register_user.dart';
import 'forget_password.dart';


class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final UserApiHandler _apiService = UserApiHandler();

  void _login() async {
    final email = _emailController.text;
    final password = _passwordController.text;
    bool isUserLoggedIn = await _apiService.loginUser(email, password);
    if (isUserLoggedIn) {
      Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(
              builder: (context) => Mainpage()),
              (route)=>route.isCurrent);
    }
    else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to login')),
      );
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(
              height: 100,
            ),
            const Text(
              'Welcome Back',
              style: TextStyle(
                color: Color(0xff770737),
                fontSize: 28,
                fontWeight: FontWeight.w600,
              ),
            ),
            const Text(
              'We are glad to see you again!',
              style: TextStyle(
                color: Colors.black,
                // fontSize: 17,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(
              height: 24,
            ),
            PrimaryTextField(
              prefixIcon: const Icon(
                Icons.email,
                size: 26,
                color: Color(0xff770737),
              ),
              controller: _emailController,
              text: 'Email address',
            ),
            const SizedBox(
              height: 16,
            ),
            PrimaryTextField(
              prefixIcon: const Icon(
                Icons.lock,
                size: 26,
                color: Color(0xff770737),
              ),
              controller: _passwordController,
              text: 'Password',
            ),
            const SizedBox(
              height: 16,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ForgetPassword()));
                  },
                  child: const Text(
                    'Forgot password?',
                    style: TextStyle(
                      color: Color(0xFF2E4EBF),
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 44,
            ),
            SizedBox(
              height: 48,
              width: MediaQuery.of(context).size.width,
              child: ElevatedButton(
                onPressed: _login,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xff770737),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(
                        6.0), // Set the border radius as needed
                  ),
                ),
                child: const Text(
                  'Sign In',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
            const SizedBox(height: 14),
            SizedBox(
              height: 48,
              width: MediaQuery.of(context).size.width,
              child: ElevatedButton(
                onPressed: () {
                  GoogleSignInApi.signIn(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange.shade500,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(
                        6.0), // Set the border radius as needed
                  ),
                ),
                child: const Text(
                  'Login With Google',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
            const SizedBox(
              height: 22,
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>  SignupPage()));
              },
              child: const Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Don’t have an account? ',
                    style: TextStyle(
                      color: Color(0xFF828A89),
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  Text(
                    'Sign Up!',
                    style: TextStyle(
                      color: Color(0xff770737),
                      // fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
