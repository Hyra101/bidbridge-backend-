import 'package:flutter/material.dart';
import 'package:untitled/login_screen/LoginApiHandler.dart';
import 'package:untitled/login_screen/RegisterApiHandler.dart';
import 'package:untitled/login_screen/login_screen.dart';

import '../widgets/primary_textfield.dart';

class NewPassword extends StatefulWidget {
  String token;
  NewPassword({Key? key, required this.token});

  @override
  State<NewPassword> createState() => _NewPasswordState();
}

class _NewPasswordState extends State<NewPassword> {
  TextEditingController newPasswordController = TextEditingController();

  void updatePassword()async {

    if (newPasswordController.text.isEmpty) {
      _showSnackBar("Please enter password");
    }else if(newPasswordController.text.length<6){
      _showSnackBar("Password length must be 6");
    }
    else {
      UserApiHandler userApiHandler = UserApiHandler();
      var response = await userApiHandler.changePassword(newPasswordController.text, widget.token);
      if(response==true){
        _showSnackBar("Password updated successfully");
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_){
          return LoginScreen();
        }));
      }else{
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text("Try again")));
      }
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Reset your password',
              style: TextStyle(
                color: Color(0xff770737),
                fontSize: 24,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(
              height: 33,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'New Password',
                  style: TextStyle(
                    color: Color(0xFF3D3D3D),
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(
                  height: 8,
                ),
                PrimaryTextField(
                  prefixIcon: const Icon(
                    Icons.lock,
                    size: 26,
                    color: Color(0xff770737),
                  ),
                  controller: newPasswordController,
                  text: 'Enter new password',
                ),
                const SizedBox(
                  height: 40,
                ),
                Center(
                  child: Stack(
                    children: [
                      InkWell(
                        onTap: () async{
                          updatePassword();
                        },
                        child: Container(
                          height: 50,
                          width: 349 * 12,
                          decoration: BoxDecoration(
                            color: Color(0xff770737),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Center(
                            child: Text(
                              'Save',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
