import 'package:flutter/material.dart';

class ImageScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Center(
        child: Container(
          constraints: BoxConstraints.expand(), // Expand the container to fill the available space
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/images/messageScreen.jpg'), // Path to your image
              fit: BoxFit.contain, // Cover the entire screen
            ),
          ),
        ),
      ),
    );
  }
}