import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // For formatting dates
import 'package:http/http.dart' as http;
import '../animation.dart';
import 'Notifications_Model.dart';
import '../login_screen/RegisterApiHandler.dart'; // Adjust import based on actual location

class NotificationsScreen extends StatefulWidget {
  @override
  _NotificationsScreenState createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  UserApiHandler userApiHandler = UserApiHandler();

  Future<Map<String, dynamic>> fetchTaskById(String taskId) async {
    final response = await http.get(Uri.parse('$appBaseUrl/tasks/task/$taskId'));

    if (response.statusCode == 200) {
      return json.decode(response.body)['task'];
    } else {
      return {}; // Return empty map for unknown tasks
    }
  }

  Future<Map<String, dynamic>> fetchJobById(String jobId) async {
    final response = await http.get(Uri.parse('$appBaseUrl/jobs/job/$jobId'));

    if (response.statusCode == 200) {
      return json.decode(response.body)['job'];
    } else {
      return {}; // Return empty map for unknown jobs
    }
  }

  Future<Map<String, dynamic>> getUserDetailsById(String userId) async {
    final response = await http.get(
      Uri.parse('$appBaseUrl/users/details/$userId'),
      headers: {'Content-Type': 'application/json'},
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body)["user"];
    } else {
      throw Exception('Failed to load user details');
    }
  }

  Future<List<Map<String, dynamic>>> getNotificationsWithDetails() async {
    var _userDetails = await userApiHandler.getUserDetails();
    List<dynamic> notificationsJson = _userDetails!["user"]['data']["notifications"];
    List<NotificationModel> notifications = parseNotifications(notificationsJson);
    print(notifications);

    // Sort notifications by createdAt
    notifications.sort((a, b) => b.createdAt.compareTo(a.createdAt));

    List<Map<String, dynamic>> notificationsWithDetails = [];

    for (var notification in notifications) {
      Map<String, dynamic> notificationDetail = {
        'notification': notification,
        'title': '',
        'subtitle': '',
        'name': '',
        'icon': Icons.notifications, // Default icon
        'color': Colors.blueAccent // Default color
      };

      if (notification is JobApplicationNotification) {
        try {
          var jobDetails = await fetchJobById(notification.jobId);
          var userDetails = await getUserDetailsById(notification.applicantId);
          if (jobDetails.isNotEmpty) {
            notificationDetail['title'] = 'Job Application for: ${jobDetails['title']}';
          } else {
            notificationDetail['title'] = 'Job Application for: Unknown Job';
          }
          notificationDetail['subtitle'] = 'Applied by: ${userDetails["name"]}';
          notificationDetail['icon'] = Icons.work;
          notificationDetail['color'] = Colors.greenAccent;
        } catch (e) {
          notificationDetail['title'] = 'Job Application for: Unknown Job';
          notificationDetail['subtitle'] = 'Applied by: ${notification.applicantId}';
        }
      }
      else if (notification is PlaceBidNotification) {
        try {
          var taskDetails = await fetchTaskById(notification.taskId);
          var userDetails = await getUserDetailsById(notification.bidderId);
          if (taskDetails.isNotEmpty) {
            notificationDetail['title'] = 'Bid placed on: ${taskDetails['title']}';
          } else {
            notificationDetail['title'] = 'Bid placed on: Unknown Task';
          }
          notificationDetail['subtitle'] = 'Bidder: ${userDetails["name"]}';
          notificationDetail['icon'] = Icons.monetization_on;
          notificationDetail['color'] = Colors.orangeAccent;
        } catch (e) {
          notificationDetail['title'] = 'Bid placed on: Unknown Task';
          notificationDetail['subtitle'] = 'Bidder ID: ${notification.bidderId}';
        }
      }

      notificationsWithDetails.add(notificationDetail);
    }

    return notificationsWithDetails;
  }

  List<NotificationModel> parseNotifications(List<dynamic> notificationsJson) {
    return notificationsJson
        .where((notificationJson) {
      // Check if the notification type is 'place-bid' or 'job-application'
      return notificationJson['type'] == 'place-bid' || notificationJson['type'] == 'job-application';
    })
        .map((notificationJson) {
      // Create the appropriate NotificationModel subclass
      return NotificationModel.fromJson(notificationJson);
    })
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Notifications'),
        backgroundColor: appConstColor,
        elevation: 10,
        actions: [
          IconButton(
            icon: Icon(Icons.settings),
            onPressed: () {
            },
          ),
        ],
      ),
      body: FutureBuilder(
        future: getNotificationsWithDetails(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('No notifications available.'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No notifications available.'));
          }
          final notificationsWithDetails = snapshot.data!;
          return ListView.builder(
            padding: EdgeInsets.symmetric(vertical: 8),
            itemCount: notificationsWithDetails.length,
            itemBuilder: (context, index) {
              final notificationDetail = notificationsWithDetails[index];
              final notification = notificationDetail['notification'] as NotificationModel;
              final title = notificationDetail['title'] as String;
              final subtitle = notificationDetail['subtitle'] as String;
              final icon = notificationDetail['icon'] as IconData;
              final color = notificationDetail['color'] as Color;

              return Card(
                margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                elevation: 6,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                child: ListTile(
                  contentPadding: EdgeInsets.all(12),
                  leading: CircleAvatar(
                    backgroundColor: color.withOpacity(0.2),
                    child: Icon(icon, color: color),
                  ),
                  title: Text(
                    title,
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.black87),
                  ),
                  subtitle: Text(
                    subtitle,
                    style: TextStyle(color: Colors.black54),
                  ),
                  trailing: Text(
                    DateFormat('yyyy-MM-dd HH:mm:ss').format(
                      DateTime.fromMillisecondsSinceEpoch(notification.createdAt),
                    ),
                    style: TextStyle(color: Colors.grey[600], fontSize: 12),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
