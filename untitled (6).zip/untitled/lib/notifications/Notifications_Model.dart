import 'package:flutter/material.dart';

// Define a base class for Notification
abstract class NotificationModel {
  final String type;
  final int createdAt;
  final bool isRead;

  NotificationModel({
    required this.type,
    required this.createdAt,
    required this.isRead,
  });

  // Factory method to create the appropriate subclass
  factory NotificationModel.fromJson(Map<String, dynamic> json) {
    switch (json['type']) {
      case 'place-bid':
        return PlaceBidNotification.fromJson(json);
      case 'job-application':
        return JobApplicationNotification.fromJson(json);
      default:
        throw Exception('Unknown notification type');
    }
  }

  // Convert to JSON
  Map<String, dynamic> toJson();
}

// Subclass for place-bid notifications
class PlaceBidNotification extends NotificationModel {
  final String bidderId;
  final String taskId;

  PlaceBidNotification({
    required this.bidderId,
    required this.taskId,
    required int createdAt,
    required bool isRead,
  }) : super(type: 'place-bid', createdAt: createdAt, isRead: isRead);

  factory PlaceBidNotification.fromJson(Map<String, dynamic> json) {
    return PlaceBidNotification(
      bidderId: json['bidderId'],
      taskId: json['taskId'],
      createdAt: json['createdAt'],
      isRead: json['isRead'],
    );
  }

  @override
  Map<String, dynamic> toJson() {
    return {
      'type': type,
      'bidderId': bidderId,
      'taskId': taskId,
      'createdAt': createdAt,
      'isRead': isRead,
    };
  }
}

// Subclass for job-application notifications
class JobApplicationNotification extends NotificationModel {
  final String applicantId;
  final String jobId;

  JobApplicationNotification({
    required this.applicantId,
    required this.jobId,
    required int createdAt,
    required bool isRead,
  }) : super(type: 'job-application', createdAt: createdAt, isRead: isRead);

  factory JobApplicationNotification.fromJson(Map<String, dynamic> json) {
    return JobApplicationNotification(
      applicantId: json['applicantId'],
      jobId: json['jobId'],
      createdAt: json['createdAt'],
      isRead: json['isRead'],
    );
  }

  @override
  Map<String, dynamic> toJson() {
    return {
      'type': type,
      'applicantId': applicantId,
      'jobId': jobId,
      'createdAt': createdAt,
      'isRead': isRead,
    };
  }
}


