
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:untitled/Home%20Screen/MainPage.dart';
import 'package:untitled/login_screen/LoginApiHandler.dart';
import 'package:untitled/login_screen/RegisterApiHandler.dart';
import 'package:untitled/login_screen/signup.dart';

class GoogleSignInApi{
  static final googleSignIn = GoogleSignIn();
  static Future<GoogleSignInAccount?> login()async {
    return await googleSignIn.signIn();
  }

  static Future<GoogleSignInAccount?> signIn(BuildContext context) async{
    final user = await GoogleSignInApi.login();
    if(user==null){
      print("Sign in failed");
    }
    else{
      UserApiHandler userApiHandler = UserApiHandler();
      final response =await userApiHandler.generateTokenByEmail(user.email.trim());
      print(response);
      if(response!= null){
        Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
                builder: (context) => Mainpage()),
                (route)=>route.isCurrent);
      }
      else{
        Navigator.push(context, MaterialPageRoute(builder: (_){
          return SignupPage(email: user.email,userName: user.displayName,);
        }));
      }
    }
    return user;
  }

  static Future<void> logout()async {
    try{
      await googleSignIn.signOut();
    }
    catch (e){

    }
  }


}